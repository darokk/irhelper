# IR Diéta Segéd

Android companion app for following an insulin-resistance (IR) diet protocol.
Designed for the Hungarian dietary protocol; complements [Yazio](https://www.yazio.com/) for planning,
shopping, and cooking — without duplicating its calorie-logging job.

## Milestone A (current) — Foundations

- ✅ Single-user profile · CH target calculation (IR clamp 130–180 g, or non-IR 45%)
- ✅ Ingredient DB + Recipe DB seeded from JSON assets on first launch
- ✅ Recipes screen — browse & search with slot/speed filters
- ✅ Planner screen — 7×6 weekly grid, manual recipe assignment per slot
- ✅ Shopping list — derived from plan ingredients, aisle-grouped, swipe-to-delete, manual add
- ✅ Today screen — next meal card, day schedule, remaining CH budget
- ✅ Cooking screen — recipe detail, scaled ingredients, instruction renderer

## Tech stack

| Layer | Library |
|---|---|
| Language | Kotlin 2.x |
| UI | Jetpack Compose · Material 3 |
| Navigation | Navigation-Compose |
| DB | Room (KSP) |
| DI | Koin |
| Async | Kotlin Coroutines + Flow |
| Date/Time | kotlinx-datetime |
| JSON | kotlinx-serialization |
| Settings | DataStore Preferences |
| Tests | JUnit 5 · Truth |

## Project structure

```
app/src/main/kotlin/com/darokk/irhelper/
├── data/
│   ├── local/          # Room entities, DAOs, Database, TypeConverters
│   ├── repository/     # Repositories + entity↔domain mappers
│   └── seed/           # SeedLoader, seed JSON models
├── di/                 # Koin AppModule
├── domain/
│   ├── model/          # Enums, domain data classes
│   ├── usecase/        # Business logic use cases
│   └── util/           # CHCalc, SlotDefaults
└── ui/
    ├── components/     # Shared composables
    ├── cooking/        # Recipe detail + instructions
    ├── navigation/     # AppNavigation, route constants
    ├── planner/        # 7×6 week grid
    ├── recipes/        # Browse + filter + RecipePicker bottom sheet
    ├── settings/       # User profile setup
    ├── shopping/       # Aisle-grouped list
    ├── theme/          # Material 3 colour + typography
    └── today/          # Next-meal card + daily overview
```

## Getting started

1. Clone this repo.
2. Copy `ingredients.json` and `recipes.json` into
   `app/src/main/assets/seed/` (files are in project root).
3. Open in Android Studio Ladybug (2024.2) or later.
4. Run on any device / emulator with Android 8.0+ (API 26+).

## Roadmap

| Milestone | Feature set |
|---|---|
| **A (done)** | Foundations — single user, local DB, manual planning |
| B | Auto-generate plan · pantry tracking |
| C | Multi-user · per-user portions |
| D | Supplement reminders · walk / vinegar nudges |
| E | Google Drive sync between partners' phones |
| F | Polish — onboarding, aisle-sorted list, user-added recipes |

See `docs/Architecture.md` for the full specification.

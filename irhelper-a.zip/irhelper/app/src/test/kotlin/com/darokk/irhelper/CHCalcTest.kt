package com.darokk.irhelper

import com.darokk.irhelper.domain.model.SlotSchedule
import com.darokk.irhelper.domain.model.User
import com.darokk.irhelper.domain.util.CHCalc
import com.darokk.irhelper.domain.util.SlotDefaults
import com.google.common.truth.Truth.assertThat
import kotlinx.datetime.Clock
import org.junit.jupiter.api.Test

class CHCalcTest {

    private fun makeUser(
        calorieTarget: Int,
        hasIR: Boolean,
        chFractionOverride: Double? = null,
        chTargetOverride: Int? = null,
    ) = User(
        id                 = "test",
        name               = "Teszt",
        hasIR              = hasIR,
        calorieTarget      = calorieTarget,
        chFractionOverride = chFractionOverride,
        chTargetOverride   = chTargetOverride,
        slotSchedule       = SlotSchedule(),
        slotTargetsGrams   = emptyMap(),
        createdAt          = Clock.System.now(),
        updatedAt          = Clock.System.now(),
    )

    @Test fun `IR user 1800 kcal gets clamped to 130-180 range`() {
        // 1800 * 0.35 / 4 = 157.5 → 158 g, within range
        val result = CHCalc.computeTarget(makeUser(1800, hasIR = true))
        assertThat(result.effectiveGrams).isEqualTo(158)
        assertThat(result.wasClamped).isFalse()
        assertThat(result.isFullyManual).isFalse()
    }

    @Test fun `IR user 1200 kcal raw below minimum gets clamped to 130`() {
        // 1200 * 0.35 / 4 = 105 g → below 130 → clamped to 130
        val result = CHCalc.computeTarget(makeUser(1200, hasIR = true))
        assertThat(result.rawComputedGrams).isLessThan(130)
        assertThat(result.effectiveGrams).isEqualTo(130)
        assertThat(result.wasClamped).isTrue()
        assertThat(result.clampReason).isNotNull()
    }

    @Test fun `IR user 2400 kcal raw above maximum gets clamped to 180`() {
        // 2400 * 0.35 / 4 = 210 g → above 180 → clamped to 180
        val result = CHCalc.computeTarget(makeUser(2400, hasIR = true))
        assertThat(result.rawComputedGrams).isGreaterThan(180)
        assertThat(result.effectiveGrams).isEqualTo(180)
        assertThat(result.wasClamped).isTrue()
    }

    @Test fun `non-IR user uses 45% fraction, no clamp`() {
        // 2000 * 0.45 / 4 = 225 g
        val result = CHCalc.computeTarget(makeUser(2000, hasIR = false))
        assertThat(result.effectiveGrams).isEqualTo(225)
        assertThat(result.wasClamped).isFalse()
    }

    @Test fun `manual override bypasses all computation`() {
        val result = CHCalc.computeTarget(makeUser(2000, hasIR = true, chTargetOverride = 150))
        assertThat(result.effectiveGrams).isEqualTo(150)
        assertThat(result.isFullyManual).isTrue()
        assertThat(result.wasClamped).isFalse()
    }

    @Test fun `custom fraction override is respected`() {
        // 2000 * 0.40 / 4 = 200 g, clamped to 180 for IR
        val result = CHCalc.computeTarget(makeUser(2000, hasIR = true, chFractionOverride = 0.40))
        assertThat(result.rawComputedGrams).isEqualTo(200)
        assertThat(result.effectiveGrams).isEqualTo(180)
        assertThat(result.wasClamped).isTrue()
    }
}

class SlotDefaultsTest {

    @Test fun `default slot targets sum to protocol total`() {
        val total = SlotDefaults.grams.values.sum()
        assertThat(total).isEqualTo(170) // Protocol as-written sums to 170
    }

    @Test fun `defaultTargets scales proportionally`() {
        val targets = SlotDefaults.defaultTargets(170) // 1:1 with protocol
        assertThat(targets.values.sum()).isEqualTo(170)
    }

    @Test fun `REGGELI and UTOVACSORA are slow-only`() {
        assertThat(com.darokk.irhelper.domain.model.Slot.REGGELI.isSlowOnly()).isTrue()
        assertThat(com.darokk.irhelper.domain.model.Slot.UTOVACSORA.isSlowOnly()).isTrue()
        assertThat(com.darokk.irhelper.domain.model.Slot.EBED.isSlowOnly()).isFalse()
        assertThat(com.darokk.irhelper.domain.model.Slot.VACSORA.isSlowOnly()).isFalse()
    }

    @Test fun `rescaleSlotTargets preserves ratio`() {
        val original = mapOf(
            com.darokk.irhelper.domain.model.Slot.REGGELI to 30,
            com.darokk.irhelper.domain.model.Slot.EBED    to 50,
        )
        val rescaled = CHCalc.rescaleSlotTargets(original, 160)
        // 30/80 * 160 = 60, 50/80 * 160 = 100
        assertThat(rescaled[com.darokk.irhelper.domain.model.Slot.REGGELI]).isEqualTo(60)
        assertThat(rescaled[com.darokk.irhelper.domain.model.Slot.EBED]).isEqualTo(100)
    }
}

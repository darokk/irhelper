package com.darokk.irhelper.domain.model

/** The six daily eating slots from the Hungarian IR protocol. */
enum class Slot {
    REGGELI,    // Breakfast    06:30–08:00  30 g CH (slow only)
    TIZORAI,    // Mid-morning  09:30–11:00  20 g CH
    EBED,       // Lunch        12:00–14:00  50 g CH
    UZSONNA,    // Afternoon    15:00–17:00  20 g CH
    VACSORA,    // Dinner       18:00–20:00  40 g CH
    UTOVACSORA; // Evening      21:00–22:00  10 g CH (slow only)

    fun displayName(): String = when (this) {
        REGGELI    -> "Reggeli"
        TIZORAI    -> "Tízórai"
        EBED       -> "Ebéd"
        UZSONNA    -> "Uzsonna"
        VACSORA    -> "Vacsora"
        UTOVACSORA -> "Utóvacsora"
    }

    /** True if this slot allows only SLOW carbs (IR rule). */
    fun isSlowOnly(): Boolean = this == REGGELI || this == UTOVACSORA
}

/** Glycaemic speed classification for ingredients and recipes. */
enum class CarbSpeed {
    SLOW,         // Low-GI; safe in all slots
    MEDIUM,       // Moderate-GI; discouraged at REGGELI/UTOVACSORA
    FAST,         // High-GI; only UZSONNA/TIZORAI; capped at EBED/VACSORA
    NOT_COUNTED;  // Protein/fat dominant; CH not meaningful (e.g. eggs, meat)
}

enum class IngredientCategory {
    DAIRY, MEAT, FISH, EGGS,
    PRODUCE_VEG, PRODUCE_FRUIT,
    GRAINS_BREAD, LEGUMES,
    NUTS_SEEDS, OILS_FATS,
    CONDIMENTS, BEVERAGES, SWEETS, OTHER
}

enum class StoreAisle {
    PRODUCE, DAIRY, MEAT, FISH, BAKERY,
    DRY_GOODS, CANNED, FROZEN,
    CONDIMENTS, BEVERAGES, HOUSEHOLD, OTHER
}

enum class ShelfLifeClass {
    PERISHABLE, // Fresh veg, dairy, raw meat — 3–7 days
    SHORT,      // Bread, cut cheese — 1–3 weeks
    STAPLE      // Rice, oats, tins, frozen — months
}

enum class ItemKind { PLAN_FOOD, MANUAL_FOOD, NON_FOOD }

enum class PantryLocation { FRIDGE, FREEZER, PANTRY }

enum class DosageUnit { MG, MCG, IU, G, CAPSULE, ML, DROP }

enum class SlotStatus {
    PLANNED,   // App generates meal, contributes to shopping list
    SKIPPED,   // User skips this slot on this day-of-week
    EXTERNAL   // Eaten outside the app (work lunch etc.); no recipe generated
}

package com.darokk.irhelper.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darokk.irhelper.domain.model.CarbSpeed
import com.darokk.irhelper.domain.model.Slot
import com.darokk.irhelper.domain.util.SlotDefaults
import com.darokk.irhelper.ui.theme.*

// ---------------------------------------------------------------------------
// CarbSpeedChip
// ---------------------------------------------------------------------------

@Composable
fun CarbSpeedChip(speed: CarbSpeed, modifier: Modifier = Modifier) {
    val (label, bg) = when (speed) {
        CarbSpeed.SLOW        -> "LASSÚ"       to CarbSpeedSlowColor
        CarbSpeed.MEDIUM      -> "KÖZÉP"        to CarbSpeedMedColor
        CarbSpeed.FAST        -> "GYORS"        to CarbSpeedFastColor
        CarbSpeed.NOT_COUNTED -> "–"            to CarbSpeedNcColor
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg.copy(alpha = 0.18f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text  = label,
            color = bg,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        )
    }
}

// ---------------------------------------------------------------------------
// SlotBadge — compact coloured label for a slot
// ---------------------------------------------------------------------------

@Composable
fun SlotBadge(slot: Slot, modifier: Modifier = Modifier) {
    val time = SlotDefaults.times[slot]
    AssistChip(
        onClick   = {},
        label     = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(slot.displayName(), style = MaterialTheme.typography.labelMedium)
                if (time != null)
                    Text(time.toString(), style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        modifier  = modifier,
        colors    = AssistChipDefaults.assistChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ),
    )
}

// ---------------------------------------------------------------------------
// CHBudgetRow — "50 g SZ" with coloured bar
// ---------------------------------------------------------------------------

@Composable
fun CHBudgetRow(
    slot: Slot,
    targetGrams: Int,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text  = slot.displayName(),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.width(80.dp),
        )
        Text(
            text  = "$targetGrams g SZ",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold,
        )
        if (slot.isSlowOnly()) {
            Text(
                text  = "csak lassú",
                style = MaterialTheme.typography.labelSmall,
                color = CarbSpeedSlowColor,
            )
        }
    }
}

// ---------------------------------------------------------------------------
// RecipeSummaryCard — used in recipe list and planner cell detail
// ---------------------------------------------------------------------------

@Composable
fun RecipeSummaryCard(
    name: String,
    chPerServing: Double,
    speed: CarbSpeed,
    slots: Set<Slot>,
    prepMinutes: Int,
    cookMinutes: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick   = onClick,
        modifier  = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                Text(
                    text     = name,
                    style    = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                CarbSpeedChip(speed)
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text  = "%.0f g SZ/adag".format(chPerServing),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text("·", color = MaterialTheme.colorScheme.outline)
                Text(
                    text  = "${prepMinutes + cookMinutes} perc",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (slots.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    slots.take(3).forEach { slot ->
                        Text(
                            text      = slot.displayName(),
                            style     = MaterialTheme.typography.labelSmall,
                            color     = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier  = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 5.dp, vertical = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// EmptyState — reusable placeholder
// ---------------------------------------------------------------------------

@Composable
fun EmptyState(
    message: String,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text  = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------------------------------------------------------------------------
// SectionHeader
// ---------------------------------------------------------------------------

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        text     = title.uppercase(),
        style    = MaterialTheme.typography.labelMedium,
        color    = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(vertical = 4.dp),
    )
}

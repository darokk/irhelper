package com.darokk.irhelper.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.*
import androidx.navigation.compose.*
import com.darokk.irhelper.ui.cooking.CookingScreen
import com.darokk.irhelper.ui.planner.PlannerScreen
import com.darokk.irhelper.ui.recipes.RecipesScreen
import com.darokk.irhelper.ui.settings.SettingsScreen
import com.darokk.irhelper.ui.shopping.ShoppingScreen
import com.darokk.irhelper.ui.today.TodayScreen

// ---------------------------------------------------------------------------
// Route constants
// ---------------------------------------------------------------------------

object Routes {
    const val TODAY    = "today"
    const val PLANNER  = "planner"
    const val SHOPPING = "shopping"
    const val RECIPES  = "recipes"
    const val SETTINGS = "settings"
    const val COOKING  = "cooking/{recipeId}"

    fun cooking(recipeId: String) = "cooking/$recipeId"
}

// ---------------------------------------------------------------------------
// Bottom-nav items
// ---------------------------------------------------------------------------

data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector = icon,
)

private val bottomNavItems = listOf(
    BottomNavItem(Routes.TODAY,    "Ma",          Icons.Filled.Today,         Icons.Filled.Today),
    BottomNavItem(Routes.PLANNER,  "Tervező",     Icons.Filled.CalendarMonth, Icons.Filled.CalendarMonth),
    BottomNavItem(Routes.SHOPPING, "Bevásárlás",  Icons.Filled.ShoppingCart,  Icons.Filled.ShoppingCart),
)

// ---------------------------------------------------------------------------
// AppNavigation
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Routes that show the bottom nav bar
    val bottomNavRoutes = bottomNavItems.map { it.route }
    val showBottomBar = currentRoute in bottomNavRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        NavigationBarItem(
                            selected  = currentRoute == item.route,
                            onClick   = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon      = {
                                Icon(
                                    if (currentRoute == item.route) item.selectedIcon else item.icon,
                                    contentDescription = item.label,
                                )
                            },
                            label     = { Text(item.label) },
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = Routes.TODAY,
            modifier         = Modifier.padding(innerPadding),
        ) {
            composable(Routes.TODAY) {
                TodayScreen(
                    onViewRecipe   = { recipeId -> navController.navigate(Routes.cooking(recipeId)) },
                    onOpenPlanner  = { navController.navigate(Routes.PLANNER) },
                    onOpenShopping = { navController.navigate(Routes.SHOPPING) },
                )
            }
            composable(Routes.PLANNER) {
                PlannerScreen(
                    onViewRecipe = { recipeId -> navController.navigate(Routes.cooking(recipeId)) },
                    onOpenRecipes = { navController.navigate(Routes.RECIPES) },
                )
            }
            composable(Routes.SHOPPING) {
                ShoppingScreen()
            }
            composable(Routes.RECIPES) {
                RecipesScreen(
                    onRecipeClick = { recipeId -> navController.navigate(Routes.cooking(recipeId)) },
                    onNavigateUp  = { navController.navigateUp() },
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable(
                route     = Routes.COOKING,
                arguments = listOf(navArgument("recipeId") { type = NavType.StringType }),
            ) { backStack ->
                val recipeId = backStack.arguments?.getString("recipeId") ?: return@composable
                CookingScreen(
                    recipeId    = recipeId,
                    onNavigateUp = { navController.navigateUp() },
                )
            }
        }
    }
}

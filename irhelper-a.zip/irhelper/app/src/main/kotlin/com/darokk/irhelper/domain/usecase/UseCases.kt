package com.darokk.irhelper.domain.usecase

import com.darokk.irhelper.data.repository.IngredientRepository
import com.darokk.irhelper.data.repository.PlanRepository
import com.darokk.irhelper.data.repository.RecipeRepository
import com.darokk.irhelper.data.repository.ShoppingListRepository
import com.darokk.irhelper.data.repository.UserRepository
import com.darokk.irhelper.domain.model.ItemKind
import com.darokk.irhelper.domain.model.PlannedMeal
import com.darokk.irhelper.domain.model.Recipe
import com.darokk.irhelper.domain.model.ShoppingListItem
import com.darokk.irhelper.domain.model.Slot
import com.darokk.irhelper.domain.model.StoreAisle
import com.darokk.irhelper.domain.util.CHCalc
import com.darokk.irhelper.domain.util.CHTargetResult
import com.darokk.irhelper.domain.util.SlotDefaults
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.datetime.Clock
import kotlinx.datetime.LocalDate
import kotlinx.datetime.TimeZone
import kotlinx.datetime.todayIn
import java.util.UUID

// ---------------------------------------------------------------------------
// ComputeCHTargetUseCase
// ---------------------------------------------------------------------------

class ComputeCHTargetUseCase(private val userRepo: UserRepository) {
    suspend operator fun invoke(): CHTargetResult? {
        val user = userRepo.activeUser.first() ?: return null
        return CHCalc.computeTarget(user)
    }
}

// ---------------------------------------------------------------------------
// GetTodayMealsUseCase
// ---------------------------------------------------------------------------

/**
 * Returns today's planned meals in slot order, with "next upcoming" logic.
 * Milestone A: no time-based filtering — show all slots in order.
 */
class GetTodayMealsUseCase(private val planRepo: PlanRepository) {
    fun invoke(date: LocalDate): Flow<List<PlannedMeal>> =
        planRepo.mealsForDate(date)
}

// ---------------------------------------------------------------------------
// GetNextMealUseCase
// ---------------------------------------------------------------------------

class GetNextMealUseCase(private val planRepo: PlanRepository) {
    suspend fun invoke(): PlannedMeal? {
        val today = Clock.System.todayIn(TimeZone.currentSystemDefault())
        val meals = planRepo.mealsForDate(today).first()
        return meals.firstOrNull { !it.isCooked }
    }
}

// ---------------------------------------------------------------------------
// AssignRecipeToSlotUseCase
// ---------------------------------------------------------------------------

class AssignRecipeToSlotUseCase(
    private val planRepo: PlanRepository,
    private val recipeRepo: RecipeRepository,
) {
    /**
     * Assigns [recipe] to the ([date], [slot]) cell in [planId].
     * Replaces any existing assignment. Creates a new PlannedMeal row.
     */
    suspend operator fun invoke(
        planId: String,
        date: LocalDate,
        slot: Slot,
        recipe: Recipe,
    ) {
        // Remove existing meal in this cell (if any)
        planRepo.deleteMealAt(planId, date, slot)

        val meal = PlannedMeal(
            id             = UUID.randomUUID().toString(),
            planId         = planId,
            date           = date,
            slot           = slot,
            recipeId       = recipe.id,
            recipeName     = recipe.nameHu,
            chPerServing   = recipe.chPerServing,
            servingsCooked = 1.0,
            pairedMealIds  = emptyList(),
            isCooked       = false,
            notes          = null,
        )
        planRepo.insertMeal(meal)
    }
}

// ---------------------------------------------------------------------------
// RemoveRecipeFromSlotUseCase
// ---------------------------------------------------------------------------

class RemoveRecipeFromSlotUseCase(private val planRepo: PlanRepository) {
    suspend operator fun invoke(planId: String, date: LocalDate, slot: Slot) {
        planRepo.deleteMealAt(planId, date, slot)
    }
}

// ---------------------------------------------------------------------------
// EnsureActiveWeekPlanUseCase
// ---------------------------------------------------------------------------

/**
 * Gets the active WeeklyPlan for the current week, creating one if absent.
 * Returns the plan id.
 */
class EnsureActiveWeekPlanUseCase(private val planRepo: PlanRepository) {
    suspend operator fun invoke(): String {
        val today = Clock.System.todayIn(TimeZone.currentSystemDefault())
        // Monday of the current ISO week
        val monday = today.let { d ->
            val dow = d.dayOfWeek.ordinal  // Mon=0 in kotlinx.datetime
            d.minus(kotlinx.datetime.DateTimeUnit.DAY, dow)
        }
        val weekId = monday.let { "W${it.year}-${it.monthNumber.toString().padStart(2, '0')}-${it.dayOfMonth.toString().padStart(2, '0')}" }
        return planRepo.getOrCreateActivePlan(weekId, monday)
    }
}

// ---------------------------------------------------------------------------
// GenerateShoppingListUseCase
// ---------------------------------------------------------------------------

/**
 * Milestone A: derive shopping list from plan ingredients.
 * No pantry subtraction yet (Milestone B).
 */
class GenerateShoppingListUseCase(
    private val planRepo: PlanRepository,
    private val recipeRepo: RecipeRepository,
    private val ingredientRepo: IngredientRepository,
    private val shoppingListRepo: ShoppingListRepository,
) {
    suspend operator fun invoke(planId: String) {
        val meals = planRepo.mealsForPlan(planId).first()
            .filter { !it.isCooked }

        // Aggregate ingredient quantities across all meals
        data class AggKey(val ingredientId: String)
        val totals = mutableMapOf<AggKey, Double>()
        val aisleMap = mutableMapOf<String, StoreAisle>()
        val labelMap = mutableMapOf<String, String>()

        for (meal in meals) {
            val recipe = recipeRepo.getById(meal.recipeId) ?: continue
            val scale = meal.servingsCooked / recipe.baseServings
            for (line in recipe.ingredients) {
                if (line.ingredientId.isBlank()) continue
                val key = AggKey(line.ingredientId)
                totals[key] = (totals[key] ?: 0.0) + line.gramsForBaseServings * scale

                if (!aisleMap.containsKey(line.ingredientId)) {
                    val ing = ingredientRepo.getById(line.ingredientId)
                    if (ing != null) {
                        aisleMap[line.ingredientId] = ing.aisle
                        labelMap[line.ingredientId] = ing.nameHu
                        // Skip assumed-available ingredients
                        if (ing.isAssumedAvailable) totals.remove(key)
                    }
                }
            }
        }

        val now = Clock.System.now()
        val items = totals.map { (key, grams) ->
            ShoppingListItem(
                id             = UUID.randomUUID().toString(),
                planId         = planId,
                ingredientId   = key.ingredientId,
                customLabel    = null,
                quantityGrams  = grams,
                quantityDisplay = formatGrams(grams),
                aisle          = aisleMap[key.ingredientId] ?: StoreAisle.OTHER,
                kind           = ItemKind.PLAN_FOOD,
                isChecked      = false,
                createdAt      = now,
            )
        }

        // Replace any existing PLAN_FOOD items for this plan
        shoppingListRepo.replacePlanItems(planId, items)
    }

    private fun formatGrams(g: Double): String = when {
        g >= 1000 -> "%.1f kg".format(g / 1000)
        else      -> "%.0f g".format(g)
    }
}

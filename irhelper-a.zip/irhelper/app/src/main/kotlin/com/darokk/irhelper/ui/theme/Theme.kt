package com.darokk.irhelper.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------
// Palette — warm earthy greens; CH budget chips in amber
// ---------------------------------------------------------------------------

private val IrGreen80    = Color(0xFFA5D6A7)
private val IrGreen40    = Color(0xFF388E3C)
private val IrGreenDark  = Color(0xFF1B5E20)
private val Amber80      = Color(0xFFFFCC80)
private val Amber40      = Color(0xFFF57C00)
private val SlowChip     = Color(0xFF66BB6A)   // green  — SLOW
private val MedChip      = Color(0xFFFFA726)   // amber  — MEDIUM
private val FastChip     = Color(0xFFEF5350)   // red    — FAST
private val NcChip       = Color(0xFF90A4AE)   // grey   — NOT_COUNTED
val CarbSpeedSlowColor  = SlowChip
val CarbSpeedMedColor   = MedChip
val CarbSpeedFastColor  = FastChip
val CarbSpeedNcColor    = NcChip

private val LightColorScheme = lightColorScheme(
    primary          = IrGreen40,
    onPrimary        = Color.White,
    primaryContainer = IrGreen80,
    secondary        = Amber40,
    onSecondary      = Color.White,
    secondaryContainer = Amber80,
    background       = Color(0xFFF9FBF9),
    surface          = Color.White,
    surfaceVariant   = Color(0xFFEEF4EE),
)

private val DarkColorScheme = darkColorScheme(
    primary          = IrGreen80,
    onPrimary        = IrGreenDark,
    primaryContainer = IrGreen40,
    secondary        = Amber80,
    onSecondary      = Color(0xFF3E2000),
    secondaryContainer = Amber40,
    background       = Color(0xFF121812),
    surface          = Color(0xFF1E261E),
    surfaceVariant   = Color(0xFF2C382C),
)

// ---------------------------------------------------------------------------
// Typography
// ---------------------------------------------------------------------------

val IRHelperTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge     = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium    = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium     = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium    = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall     = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 11.sp, lineHeight = 14.sp),
)

// ---------------------------------------------------------------------------
// Theme entry-point
// ---------------------------------------------------------------------------

@Composable
fun IRHelperTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography  = IRHelperTypography,
        content     = content,
    )
}

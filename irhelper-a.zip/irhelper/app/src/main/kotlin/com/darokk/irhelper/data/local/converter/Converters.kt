package com.darokk.irhelper.data.local.converter

import androidx.room.TypeConverter
import com.darokk.irhelper.domain.model.Slot
import com.darokk.irhelper.domain.model.SlotSchedule
import com.darokk.irhelper.domain.model.SlotStatus
import kotlinx.datetime.DayOfWeek
import kotlinx.datetime.Instant
import kotlinx.datetime.LocalDate
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val json = Json { ignoreUnknownKeys = true }

class Converters {

    // --- Instant ---

    @TypeConverter fun instantToLong(v: Instant): Long = v.toEpochMilliseconds()

    @TypeConverter fun longToInstant(v: Long): Instant = Instant.fromEpochMilliseconds(v)

    // --- LocalDate ---

    @TypeConverter fun localDateToString(v: LocalDate): String = v.toString()

    @TypeConverter fun stringToLocalDate(v: String): LocalDate = LocalDate.parse(v)

    // --- Set<Slot> ---

    @TypeConverter fun slotSetToString(v: Set<Slot>): String =
        v.joinToString(",") { it.name }

    @TypeConverter fun stringToSlotSet(v: String): Set<Slot> =
        if (v.isBlank()) emptySet()
        else v.split(",").mapNotNull { runCatching { Slot.valueOf(it.trim()) }.getOrNull() }.toSet()

    // --- Map<Slot, Int> ---

    @TypeConverter fun slotIntMapToString(v: Map<Slot, Int>): String =
        json.encodeToString<Map<String, Int>>(v.mapKeys { it.key.name })

    @TypeConverter fun stringToSlotIntMap(v: String): Map<Slot, Int> {
        if (v.isBlank()) return emptyMap()
        val raw = json.decodeFromString<Map<String, Int>>(v)
        return raw.mapNotNull { (k, grams) ->
            runCatching { Slot.valueOf(k) to grams }.getOrNull()
        }.toMap()
    }

    // --- SlotSchedule ---

    @TypeConverter fun slotScheduleToString(schedule: SlotSchedule): String {
        // Encode as Map<String, Map<String, String>> for JSON
        val encoded: Map<String, Map<String, String>> = schedule.grid
            .mapKeys { it.key.name }
            .mapValues { (_, slots) -> slots.mapKeys { it.key.name }.mapValues { it.value.name } }
        return json.encodeToString(encoded)
    }

    @TypeConverter fun stringToSlotSchedule(v: String): SlotSchedule {
        if (v.isBlank()) return SlotSchedule()
        val raw = json.decodeFromString<Map<String, Map<String, String>>>(v)
        val grid = raw.mapNotNull { (dayStr, slotMap) ->
            val day = runCatching { DayOfWeek.valueOf(dayStr) }.getOrNull() ?: return@mapNotNull null
            val slots = slotMap.mapNotNull { (slotStr, statusStr) ->
                val slot   = runCatching { Slot.valueOf(slotStr) }.getOrNull() ?: return@mapNotNull null
                val status = runCatching { SlotStatus.valueOf(statusStr) }.getOrNull() ?: SlotStatus.PLANNED
                slot to status
            }.toMap()
            day to slots
        }.toMap()
        return SlotSchedule(grid)
    }

    // --- List<String> (pairedMealIds) ---

    @TypeConverter fun stringListToString(v: List<String>): String =
        json.encodeToString(v)

    @TypeConverter fun stringToStringList(v: String): List<String> =
        if (v.isBlank()) emptyList()
        else runCatching { json.decodeFromString<List<String>>(v) }.getOrElse { emptyList() }
}

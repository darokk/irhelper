package com.darokk.irhelper.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.darokk.irhelper.data.local.converter.Converters
import com.darokk.irhelper.data.local.dao.*
import com.darokk.irhelper.data.local.entity.*

@Database(
    entities = [
        UserEntity::class,
        IngredientEntity::class,
        RecipeEntity::class,
        RecipeIngredientEntity::class,
        WeeklyPlanEntity::class,
        PlannedMealEntity::class,
        ShoppingListItemEntity::class,
    ],
    version = 1,
    exportSchema = true,   // schema exported to app/schemas/ for migration diffs
)
@TypeConverters(Converters::class)
abstract class IRHelperDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun ingredientDao(): IngredientDao
    abstract fun recipeDao(): RecipeDao
    abstract fun weeklyPlanDao(): WeeklyPlanDao
    abstract fun plannedMealDao(): PlannedMealDao
    abstract fun shoppingListDao(): ShoppingListDao

    companion object {
        const val DB_NAME = "irhelper.db"
    }
}

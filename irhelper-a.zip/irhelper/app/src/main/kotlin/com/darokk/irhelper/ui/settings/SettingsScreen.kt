package com.darokk.irhelper.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.UserRepository
import com.darokk.irhelper.domain.model.*
import com.darokk.irhelper.domain.util.CHCalc
import com.darokk.irhelper.domain.util.CHTargetResult
import com.darokk.irhelper.domain.util.SlotDefaults
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import java.util.UUID

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

data class SettingsUiState(
    val user: User? = null,
    val chTarget: CHTargetResult? = null,
    val isLoading: Boolean = true,
    val savedFeedback: Boolean = false,
)

class SettingsViewModel(
    private val userRepo: UserRepository,
    private val computeCH: com.darokk.irhelper.domain.usecase.ComputeCHTargetUseCase,
) : ViewModel() {

    private val _feedback = MutableStateFlow(false)

    val uiState: StateFlow<SettingsUiState> = combine(
        userRepo.activeUser,
        _feedback,
    ) { user, feedback ->
        SettingsUiState(
            user          = user,
            chTarget      = user?.let { CHCalc.computeTarget(it) },
            isLoading     = false,
            savedFeedback = feedback,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun saveUser(
        name: String,
        hasIR: Boolean,
        calorieTarget: Int,
    ) {
        viewModelScope.launch {
            val now = Clock.System.now()
            val existing = userRepo.getActiveUser()
            val chResult = CHCalc.computeTarget(
                User(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    name = name, hasIR = hasIR,
                    calorieTarget = calorieTarget,
                    chFractionOverride = null, chTargetOverride = null,
                    slotSchedule = existing?.slotSchedule ?: SlotSchedule(),
                    slotTargetsGrams = emptyMap(),
                    createdAt = existing?.createdAt ?: now, updatedAt = now,
                )
            )
            val slotTargets = if (existing?.slotTargetsGrams?.isNotEmpty() == true) {
                CHCalc.rescaleSlotTargets(existing.slotTargetsGrams, chResult.effectiveGrams)
            } else {
                SlotDefaults.defaultTargets(chResult.effectiveGrams)
            }

            val user = User(
                id                 = existing?.id ?: UUID.randomUUID().toString(),
                name               = name,
                hasIR              = hasIR,
                calorieTarget      = calorieTarget,
                chFractionOverride = null,
                chTargetOverride   = null,
                slotSchedule       = existing?.slotSchedule ?: SlotSchedule(),
                slotTargetsGrams   = slotTargets,
                createdAt          = existing?.createdAt ?: now,
                updatedAt          = now,
            )
            userRepo.upsert(user)
            _feedback.value = true
            kotlinx.coroutines.delay(2000)
            _feedback.value = false
        }
    }
}

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.darokk.irhelper.domain.util.SlotDefaults
import com.darokk.irhelper.ui.components.SectionHeader
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateUp: () -> Unit,
    vm: SettingsViewModel = koinViewModel(),
) {
    val state by vm.uiState.collectAsState()
    val user = state.user

    // Local form state
    var name          by remember(user?.name) { mutableStateOf(user?.name ?: "") }
    var hasIR         by remember(user?.hasIR) { mutableStateOf(user?.hasIR ?: true) }
    var calorieText   by remember(user?.calorieTarget) {
        mutableStateOf(user?.calorieTarget?.toString() ?: "")
    }

    val calorieValid = calorieText.toIntOrNull()?.let { it in 800..4000 } ?: false

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(Icons.Filled.ArrowBack, "Vissza")
                    }
                },
                title = { Text("Beállítások") },
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // --- User profile section ---
            SectionHeader("Felhasználói profil")

            OutlinedTextField(
                value         = name,
                onValueChange = { name = it },
                label         = { Text("Név") },
                leadingIcon   = { Icon(Icons.Filled.Person, null) },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth(),
            )

            OutlinedTextField(
                value         = calorieText,
                onValueChange = { calorieText = it.filter { c -> c.isDigit() } },
                label         = { Text("Kalória-cél (Yazio-ból)") },
                leadingIcon   = { Icon(Icons.Filled.LocalFireDepartment, null) },
                suffix        = { Text("kcal") },
                singleLine    = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError       = calorieText.isNotEmpty() && !calorieValid,
                supportingText = {
                    if (calorieText.isNotEmpty() && !calorieValid)
                        Text("800–4000 kcal közötti értéket adj meg")
                },
                modifier      = Modifier.fillMaxWidth(),
            )

            // IR toggle
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Inzulinrezisztencia diéta", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (hasIR) "SZ-keret: 130–180 g/nap; csak lassú SZ reggel és utóvacsorán"
                            else "Normál szénhidrát-ajánlás (45% kcal)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = hasIR, onCheckedChange = { hasIR = it })
                }
            }

            // CH target preview
            if (calorieValid) {
                val previewUser = com.darokk.irhelper.domain.model.User(
                    id = "", name = name, hasIR = hasIR,
                    calorieTarget = calorieText.toInt(),
                    chFractionOverride = null, chTargetOverride = null,
                    slotSchedule = com.darokk.irhelper.domain.model.SlotSchedule(),
                    slotTargetsGrams = emptyMap(),
                    createdAt = kotlinx.datetime.Clock.System.now(),
                    updatedAt = kotlinx.datetime.Clock.System.now(),
                )
                val chResult = com.darokk.irhelper.domain.util.CHCalc.computeTarget(previewUser)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors   = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text("Napi SZ-cél", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${chResult.effectiveGrams} g",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                        if (chResult.clampReason != null) {
                            Text(
                                chResult.clampReason,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        // Slot breakdown
                        val slotTargets = SlotDefaults.defaultTargets(chResult.effectiveGrams)
                        slotTargets.entries.forEach { (slot, grams) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(slot.displayName(), style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "$grams g${if (slot.isSlowOnly()) " (csak lassú)" else ""}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            }

            // --- Save button ---
            Button(
                onClick  = {
                    vm.saveUser(
                        name          = name.trim(),
                        hasIR         = hasIR,
                        calorieTarget = calorieText.toIntOrNull() ?: return@Button,
                    )
                },
                enabled  = name.isNotBlank() && calorieValid,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (state.savedFeedback) {
                    Icon(Icons.Filled.Check, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Mentve!")
                } else {
                    Text("Mentés")
                }
            }

            // --- App info ---
            SectionHeader("Az alkalmazásról")
            Text(
                "IR Diéta Segéd · Milestone A\nAz app offline-első, Yazio kiegészítőjeként működik.\nAdatokat nem szinkronizál (Milestone E).",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

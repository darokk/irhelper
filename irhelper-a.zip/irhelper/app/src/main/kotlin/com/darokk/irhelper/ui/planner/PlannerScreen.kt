package com.darokk.irhelper.ui.planner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.PlanRepository
import com.darokk.irhelper.data.repository.RecipeRepository
import com.darokk.irhelper.data.repository.ShoppingListRepository
import com.darokk.irhelper.domain.model.*
import com.darokk.irhelper.domain.usecase.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.datetime.*

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

data class PlannerUiState(
    val planId: String = "",
    val weekStart: LocalDate = Clock.System.todayIn(TimeZone.currentSystemDefault()),
    val meals: List<PlannedMeal> = emptyList(),
    val selectedCell: Pair<LocalDate, Slot>? = null,   // for bottom sheet
    val isLoading: Boolean = true,
    val shoppingGenerated: Boolean = false,
)

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

class PlannerViewModel(
    private val planRepo: PlanRepository,
    private val recipeRepo: RecipeRepository,
    private val shoppingRepo: ShoppingListRepository,
    private val assignUseCase: AssignRecipeToSlotUseCase,
    private val removeUseCase: RemoveRecipeFromSlotUseCase,
) : ViewModel() {

    private val _planId   = MutableStateFlow("")
    private val _weekStart = MutableStateFlow(currentMonday())
    private val _selected  = MutableStateFlow<Pair<LocalDate, Slot>?>(null)
    private val _shopDone  = MutableStateFlow(false)

    val uiState: StateFlow<PlannerUiState> = combine(
        _planId,
        _weekStart,
        _planId.flatMapLatest { id ->
            if (id.isEmpty()) flowOf(emptyList()) else planRepo.mealsForPlan(id)
        },
        _selected,
        _shopDone,
    ) { planId, weekStart, meals, selected, shopDone ->
        PlannerUiState(
            planId           = planId,
            weekStart        = weekStart,
            meals            = meals,
            selectedCell     = selected,
            isLoading        = planId.isEmpty(),
            shoppingGenerated = shopDone,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlannerUiState())

    init {
        viewModelScope.launch {
            val id = ensurePlan()
            _planId.value = id
        }
    }

    private suspend fun ensurePlan(): String {
        val today   = Clock.System.todayIn(TimeZone.currentSystemDefault())
        val monday  = currentMonday()
        val weekId  = "W${monday.year}-${monday.monthNumber.toString().padStart(2,'0')}-${monday.dayOfMonth.toString().padStart(2,'0')}"
        return planRepo.getOrCreateActivePlan(weekId, monday)
    }

    fun selectCell(date: LocalDate, slot: Slot) {
        _selected.value = date to slot
    }

    fun clearSelection() { _selected.value = null }

    fun assignRecipe(date: LocalDate, slot: Slot, recipe: Recipe) {
        val planId = _planId.value.ifEmpty { return }
        viewModelScope.launch {
            assignUseCase(planId, date, slot, recipe)
            _selected.value = null
        }
    }

    fun removeRecipe(date: LocalDate, slot: Slot) {
        val planId = _planId.value.ifEmpty { return }
        viewModelScope.launch {
            removeUseCase(planId, date, slot)
            _selected.value = null
        }
    }

    private fun currentMonday(): LocalDate {
        val today = Clock.System.todayIn(TimeZone.currentSystemDefault())
        val dow   = today.dayOfWeek.ordinal   // Mon=0
        return today.minus(dow, DateTimeUnit.DAY)
    }
}

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.darokk.irhelper.domain.util.SlotDefaults
import com.darokk.irhelper.ui.components.EmptyState
import com.darokk.irhelper.ui.recipes.RecipePickerBottomSheet
import kotlinx.datetime.*
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    onViewRecipe: (String) -> Unit,
    onOpenRecipes: () -> Unit,
    vm: PlannerViewModel = koinViewModel(),
) {
    val state by vm.uiState.collectAsState()
    var showRecipePicker by remember { mutableStateOf(false) }

    val weekDays = remember(state.weekStart) {
        (0..6).map { state.weekStart.plus(it, DateTimeUnit.DAY) }
    }

    // Map (date, slot) → meal for quick lookup
    val mealMap = remember(state.meals) {
        state.meals.associateBy { it.date to it.slot }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        buildString {
                            val ws = state.weekStart
                            append("${ws.dayOfMonth}. ")
                            append(shortMonth(ws.monthNumber))
                            append(" – ")
                            val we = ws.plus(6, DateTimeUnit.DAY)
                            append("${we.dayOfMonth}. ")
                            append(shortMonth(we.monthNumber))
                        }
                    )
                },
                actions = {
                    IconButton(onClick = onOpenRecipes) {
                        Icon(Icons.Filled.MenuBook, contentDescription = "Receptek")
                    }
                },
            )
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        // --- 7-day × 6-slot grid ---
        Column(modifier = Modifier.padding(padding)) {

            // Column headers (day names + dates)
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = SLOT_LABEL_WIDTH),
            ) {
                weekDays.forEach { day ->
                    val isToday = day == Clock.System.todayIn(TimeZone.currentSystemDefault())
                    DayHeader(day, isToday, modifier = Modifier.width(CELL_WIDTH))
                }
            }

            // Grid body (slot label + cells)
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .verticalScroll(rememberScrollState()),
            ) {
                // Slot labels column
                Column(modifier = Modifier.width(SLOT_LABEL_WIDTH)) {
                    Slot.entries.forEach { slot ->
                        SlotLabel(slot, modifier = Modifier.height(CELL_HEIGHT))
                    }
                }

                // Day columns
                weekDays.forEach { day ->
                    Column(modifier = Modifier.width(CELL_WIDTH)) {
                        Slot.entries.forEach { slot ->
                            val meal = mealMap[day to slot]
                            PlannerCell(
                                meal     = meal,
                                slot     = slot,
                                onClick  = {
                                    vm.selectCell(day, slot)
                                    showRecipePicker = true
                                },
                                modifier = Modifier.height(CELL_HEIGHT),
                            )
                        }
                    }
                }
            }
        }

        // --- Recipe picker bottom sheet ---
        if (showRecipePicker && state.selectedCell != null) {
            val (date, slot) = state.selectedCell!!
            val existingMeal = mealMap[date to slot]

            RecipePickerBottomSheet(
                slot         = slot,
                onDismiss    = { vm.clearSelection(); showRecipePicker = false },
                onSelectRecipe = { recipe ->
                    vm.assignRecipe(date, slot, recipe)
                    showRecipePicker = false
                },
                onViewRecipe   = onViewRecipe,
                onRemove       = if (existingMeal != null) ({
                    vm.removeRecipe(date, slot)
                    showRecipePicker = false
                }) else null,
            )
        }
    }
}

private val CELL_WIDTH        = 120.dp
private val CELL_HEIGHT       = 80.dp
private val SLOT_LABEL_WIDTH  = 72.dp

@Composable
private fun DayHeader(day: LocalDate, isToday: Boolean, modifier: Modifier = Modifier) {
    Column(
        modifier            = modifier.padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val containerColor = if (isToday) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.surface
        val contentColor   = if (isToday) MaterialTheme.colorScheme.onPrimary
        else MaterialTheme.colorScheme.onSurface

        Box(
            modifier            = Modifier
                .size(32.dp)
                .clip(MaterialTheme.shapes.small)
                .background(containerColor),
            contentAlignment    = Alignment.Center,
        ) {
            Text(
                day.dayOfMonth.toString(),
                style = MaterialTheme.typography.labelMedium,
                color = contentColor,
            )
        }
        Text(
            shortDay(day.dayOfWeek.ordinal),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SlotLabel(slot: Slot, modifier: Modifier = Modifier) {
    val time = SlotDefaults.times[slot]
    Column(
        modifier            = modifier.padding(horizontal = 4.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start,
    ) {
        Text(slot.displayName(), style = MaterialTheme.typography.labelMedium)
        if (time != null) {
            Text(time.displayStart, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PlannerCell(
    meal: PlannedMeal?,
    slot: Slot,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val borderColor = if (meal != null) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.outlineVariant

    Box(
        modifier = modifier
            .padding(2.dp)
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small)
            .border(BorderStroke(1.dp, borderColor), MaterialTheme.shapes.small)
            .background(
                if (meal != null) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            )
            .clickable(onClick = onClick)
            .padding(6.dp),
        contentAlignment = Alignment.TopStart,
    ) {
        if (meal != null) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    meal.recipeName,
                    style    = MaterialTheme.typography.labelSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "%.0f g SZ".format(meal.chPerServing),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                if (meal.isCooked) {
                    Icon(Icons.Filled.Check, contentDescription = "Megfőzve",
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.primary)
                }
            }
        } else {
            Icon(
                Icons.Filled.Add,
                contentDescription = "Hozzáad",
                modifier = Modifier.align(Alignment.Center).size(20.dp),
                tint = MaterialTheme.colorScheme.outline,
            )
        }
    }
}

private fun shortDay(ordinal: Int) = when (ordinal) {
    0 -> "H"; 1 -> "K"; 2 -> "Sze"; 3 -> "Cs"; 4 -> "P"; 5 -> "Szo"; 6 -> "V"; else -> ""
}

private fun shortMonth(m: Int) = when (m) {
    1 -> "jan."; 2 -> "feb."; 3 -> "már."; 4 -> "ápr."; 5 -> "máj."; 6 -> "jún."
    7 -> "júl."; 8 -> "aug."; 9 -> "szept."; 10 -> "okt."; 11 -> "nov."; 12 -> "dec."
    else -> ""
}

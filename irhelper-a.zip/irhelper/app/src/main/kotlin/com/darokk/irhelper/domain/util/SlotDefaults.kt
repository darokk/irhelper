package com.darokk.irhelper.domain.util

import com.darokk.irhelper.domain.model.Slot

/**
 * Canonical defaults from the Hungarian IR protocol (Research Report §5.2).
 * All values are per the protocol document as-written; they intentionally
 * sum to 170 g (not 160) — the protocol itself is inconsistent on the total.
 */
object SlotDefaults {

    /** Default CH target in grams per slot. */
    val grams: Map<Slot, Int> = mapOf(
        Slot.REGGELI    to 30,
        Slot.TIZORAI    to 20,
        Slot.EBED       to 50,
        Slot.UZSONNA    to 20,
        Slot.VACSORA    to 40,
        Slot.UTOVACSORA to 10,
    )

    /** Default display time range per slot (start hour to end hour). */
    data class TimeRange(val startHour: Int, val startMinute: Int,
                         val endHour: Int,   val endMinute: Int) {
        val displayStart: String get() = "%02d:%02d".format(startHour, startMinute)
        val displayEnd:   String get() = "%02d:%02d".format(endHour, endMinute)
        override fun toString(): String = "$displayStart–$displayEnd"
    }

    val times: Map<Slot, TimeRange> = mapOf(
        Slot.REGGELI    to TimeRange( 6, 30,  8,  0),
        Slot.TIZORAI    to TimeRange( 9, 30, 11,  0),
        Slot.EBED       to TimeRange(12,  0, 14,  0),
        Slot.UZSONNA    to TimeRange(15,  0, 17,  0),
        Slot.VACSORA    to TimeRange(18,  0, 20,  0),
        Slot.UTOVACSORA to TimeRange(21,  0, 22,  0),
    )

    /**
     * Build a default slot-targets map for a newly created user.
     * If the user has calorie and CH targets we scale proportionally;
     * if not, the protocol defaults are used unchanged.
     */
    fun defaultTargets(chTargetGrams: Int): Map<Slot, Int> {
        val protocolTotal = grams.values.sum() // 170
        return grams.mapValues { (_, v) ->
            ((v.toDouble() / protocolTotal) * chTargetGrams).toInt()
        }
    }
}

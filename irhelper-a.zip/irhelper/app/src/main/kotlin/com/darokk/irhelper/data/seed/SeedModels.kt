package com.darokk.irhelper.data.seed

import kotlinx.serialization.Serializable

// ---------------------------------------------------------------------------
// These models mirror the JSON structure in assets/seed/*.json exactly.
// They are intentionally separate from domain models and Room entities so
// the JSON schema can evolve independently.
// ---------------------------------------------------------------------------

@Serializable
data class SeedIngredientFile(
    val version: Int,
    val ingredients: List<SeedIngredient>,
)

@Serializable
data class SeedIngredient(
    val id: String,
    val nameHu: String,
    val nameEn: String? = null,
    val category: String,
    val aisle: String,
    val chPer100g: Double,
    val speed: String,
    val shelfLife: String,
    val shelfLifeDaysHint: Int,
    val servingHint: String? = null,
    val isAssumedAvailable: Boolean = false,
    val source: String,
    val verified: Boolean = false,
)

@Serializable
data class SeedRecipeFile(
    val version: Int,
    val recipes: List<SeedRecipe>,
)

@Serializable
data class SeedRecipe(
    val id: String,
    val nameHu: String,
    val descriptionHu: String? = null,
    val eligibleSlots: List<String>,
    val speedClassification: String,
    val baseServings: Int,
    val chPerServing: Double,
    val proteinPerServing: Double? = null,
    val fatPerServing: Double? = null,
    val fiberPerServing: Double? = null,
    val prepMinutes: Int = 0,
    val cookMinutes: Int = 0,
    val instructionsMd: String = "",
    val goodAsLeftovers: Boolean = false,
    val advancePrepHint: String? = null,
    val isIRCompliant: Boolean = true,
    val source: String = "seed",
    val verified: Boolean = false,
    val sourceCode: String? = null,
    val unresolved: List<String> = emptyList(),
    val ingredients: List<SeedRecipeIngredient> = emptyList(),
)

@Serializable
data class SeedRecipeIngredient(
    val ingredientId: String,
    val ingredientName: String,
    val gramsForBaseServings: Double,
    val prepNote: String? = null,
)

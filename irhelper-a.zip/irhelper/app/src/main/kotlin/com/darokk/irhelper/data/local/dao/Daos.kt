package com.darokk.irhelper.data.local.dao

import androidx.room.*
import com.darokk.irhelper.data.local.entity.*
import com.darokk.irhelper.domain.model.Slot
import kotlinx.coroutines.flow.Flow
import kotlinx.datetime.LocalDate

// ---------------------------------------------------------------------------
// UserDao
// ---------------------------------------------------------------------------

@Dao
interface UserDao {
    @Query("SELECT * FROM users LIMIT 1")
    fun observeActiveUser(): Flow<UserEntity?>

    @Query("SELECT * FROM users LIMIT 1")
    suspend fun getActiveUser(): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: UserEntity)

    @Update
    suspend fun update(user: UserEntity)
}

// ---------------------------------------------------------------------------
// IngredientDao
// ---------------------------------------------------------------------------

@Dao
interface IngredientDao {
    @Query("SELECT * FROM ingredients ORDER BY nameHu ASC")
    fun observeAll(): Flow<List<IngredientEntity>>

    @Query("SELECT * FROM ingredients WHERE id = :id")
    suspend fun getById(id: String): IngredientEntity?

    @Query("SELECT * FROM ingredients WHERE nameHu LIKE '%' || :query || '%' OR nameEn LIKE '%' || :query || '%' ORDER BY nameHu ASC")
    fun search(query: String): Flow<List<IngredientEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<IngredientEntity>)

    @Query("SELECT COUNT(*) FROM ingredients")
    suspend fun count(): Int
}

// ---------------------------------------------------------------------------
// RecipeDao
// ---------------------------------------------------------------------------

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes ORDER BY nameHu ASC")
    fun observeAll(): Flow<List<RecipeEntity>>

    @Query("SELECT * FROM recipes WHERE id = :id")
    suspend fun getById(id: String): RecipeEntity?

    @Query("SELECT * FROM recipes WHERE nameHu LIKE '%' || :query || '%' ORDER BY nameHu ASC")
    fun search(query: String): Flow<List<RecipeEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<RecipeEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIngredients(items: List<RecipeIngredientEntity>)

    @Query("SELECT * FROM recipe_ingredients WHERE recipeId = :recipeId")
    suspend fun getIngredientsForRecipe(recipeId: String): List<RecipeIngredientEntity>

    @Query("SELECT COUNT(*) FROM recipes")
    suspend fun count(): Int
}

// ---------------------------------------------------------------------------
// WeeklyPlanDao
// ---------------------------------------------------------------------------

@Dao
interface WeeklyPlanDao {
    @Query("SELECT * FROM weekly_plans WHERE isActive = 1 ORDER BY startDate DESC LIMIT 1")
    fun observeActivePlan(): Flow<WeeklyPlanEntity?>

    @Query("SELECT * FROM weekly_plans WHERE id = :id")
    suspend fun getById(id: String): WeeklyPlanEntity?

    @Query("SELECT * FROM weekly_plans ORDER BY startDate DESC")
    fun observeAll(): Flow<List<WeeklyPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(plan: WeeklyPlanEntity)

    @Update
    suspend fun update(plan: WeeklyPlanEntity)
}

// ---------------------------------------------------------------------------
// PlannedMealDao
// ---------------------------------------------------------------------------

@Dao
interface PlannedMealDao {
    @Query("SELECT * FROM planned_meals WHERE planId = :planId ORDER BY date ASC")
    fun observeByPlan(planId: String): Flow<List<PlannedMealEntity>>

    @Query("SELECT * FROM planned_meals WHERE date = :date ORDER BY slot ASC")
    fun observeByDate(date: LocalDate): Flow<List<PlannedMealEntity>>

    @Query("SELECT * FROM planned_meals WHERE planId = :planId AND date = :date AND slot = :slot LIMIT 1")
    suspend fun getAt(planId: String, date: LocalDate, slot: Slot): PlannedMealEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(meal: PlannedMealEntity)

    @Update
    suspend fun update(meal: PlannedMealEntity)

    @Query("DELETE FROM planned_meals WHERE planId = :planId AND date = :date AND slot = :slot")
    suspend fun deleteAt(planId: String, date: LocalDate, slot: Slot)

    @Query("DELETE FROM planned_meals WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE planned_meals SET isCooked = :cooked WHERE id = :id")
    suspend fun setCooked(id: String, cooked: Boolean)
}

// ---------------------------------------------------------------------------
// ShoppingListDao
// ---------------------------------------------------------------------------

@Dao
interface ShoppingListDao {
    @Query("SELECT * FROM shopping_list_items ORDER BY aisle ASC, customLabel ASC, createdAt ASC")
    fun observeAll(): Flow<List<ShoppingListItemEntity>>

    @Query("SELECT * FROM shopping_list_items WHERE planId = :planId")
    fun observeByPlan(planId: String): Flow<List<ShoppingListItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ShoppingListItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ShoppingListItemEntity)

    @Query("UPDATE shopping_list_items SET isChecked = :checked WHERE id = :id")
    suspend fun setChecked(id: String, checked: Boolean)

    @Query("DELETE FROM shopping_list_items WHERE planId = :planId AND kind = 'PLAN_FOOD'")
    suspend fun deletePlanFoodItems(planId: String)

    @Query("DELETE FROM shopping_list_items WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM shopping_list_items WHERE isChecked = 1")
    suspend fun deleteChecked()
}

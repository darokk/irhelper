package com.darokk.irhelper.domain.util

import com.darokk.irhelper.domain.model.User
import kotlin.math.roundToInt

/**
 * Pure CH-target calculation per Architecture §6.1.
 *
 * Result is a data class so the UI can display both the raw computed value
 * and the clamped/override value with an explanatory message when they differ.
 */
data class CHTargetResult(
    val rawComputedGrams: Int,
    val effectiveGrams: Int,
    val wasClamped: Boolean,
    val clampReason: String?,
    val isFullyManual: Boolean,
)

object CHCalc {

    private const val IR_MIN  = 130
    private const val IR_MAX  = 180
    private const val KCAL_PER_GRAM_CH = 4.0

    fun computeTarget(user: User): CHTargetResult {
        // Manual override wins unconditionally
        user.chTargetOverride?.let { override ->
            return CHTargetResult(
                rawComputedGrams = override,
                effectiveGrams   = override,
                wasClamped       = false,
                clampReason      = null,
                isFullyManual    = true,
            )
        }

        val fraction = user.chFractionOverride
            ?: if (user.hasIR) 0.35 else 0.45

        val raw = ((user.calorieTarget * fraction) / KCAL_PER_GRAM_CH).roundToInt()

        return if (user.hasIR) {
            val clamped = raw.coerceIn(IR_MIN, IR_MAX)
            val clamped_ = clamped != raw
            CHTargetResult(
                rawComputedGrams = raw,
                effectiveGrams   = clamped,
                wasClamped       = clamped_,
                clampReason      = when {
                    raw < IR_MIN -> "számított $raw g → IR minimum $IR_MIN g alkalmazva"
                    raw > IR_MAX -> "számított $raw g → IR maximum $IR_MAX g alkalmazva"
                    else         -> null
                },
                isFullyManual = false,
            )
        } else {
            CHTargetResult(
                rawComputedGrams = raw,
                effectiveGrams   = raw,
                wasClamped       = false,
                clampReason      = null,
                isFullyManual    = false,
            )
        }
    }

    /**
     * Scale existing slot targets proportionally when the user's calorie
     * target changes. Preserves any manual ratio the user established.
     */
    fun rescaleSlotTargets(
        existing: Map<com.darokk.irhelper.domain.model.Slot, Int>,
        newTotal: Int,
    ): Map<com.darokk.irhelper.domain.model.Slot, Int> {
        val oldTotal = existing.values.sum().takeIf { it > 0 } ?: return existing
        return existing.mapValues { (_, v) ->
            ((v.toDouble() / oldTotal) * newTotal).roundToInt()
        }
    }
}

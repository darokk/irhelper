package com.darokk.irhelper.ui.cooking

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.RecipeRepository
import com.darokk.irhelper.domain.model.Recipe
import com.darokk.irhelper.ui.components.CarbSpeedChip
import com.darokk.irhelper.ui.components.SectionHeader
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel
import org.koin.core.parameter.parametersOf

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

data class CookingUiState(
    val recipe: Recipe? = null,
    val isLoading: Boolean = true,
)

class CookingViewModel(
    private val recipeId: String,
    private val repo: RecipeRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(CookingUiState())
    val uiState: StateFlow<CookingUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val recipe = repo.getById(recipeId)
            _state.value = CookingUiState(recipe = recipe, isLoading = false)
        }
    }
}

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CookingScreen(
    recipeId: String,
    onNavigateUp: () -> Unit,
    vm: CookingViewModel = koinViewModel(parameters = { parametersOf(recipeId) }),
) {
    val state by vm.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Vissza")
                    }
                },
                title = { Text(state.recipe?.nameHu ?: "Recept") },
            )
        }
    ) { padding ->
        when {
            state.isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            state.recipe == null -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("A recept nem található.")
                }
            }
            else -> {
                RecipeDetailContent(
                    recipe   = state.recipe!!,
                    modifier = Modifier.padding(padding),
                )
            }
        }
    }
}

@Composable
private fun RecipeDetailContent(recipe: com.darokk.irhelper.domain.model.Recipe, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // --- Header chips ---
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            CarbSpeedChip(recipe.speedClassification)
            if (recipe.goodAsLeftovers) {
                AssistChip(onClick = {}, label = { Text("Maradékos") },
                    leadingIcon = { Icon(Icons.Filled.Refresh, null, Modifier.size(16.dp)) })
            }
            if (recipe.isIRCompliant) {
                AssistChip(onClick = {}, label = { Text("IR-kompatibilis") },
                    leadingIcon = { Icon(Icons.Filled.Verified, null, Modifier.size(16.dp)) })
            }
        }

        // --- Description ---
        recipe.descriptionHu?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // --- Macros row ---
        Card(modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                MacroCell("Szénhidrát", "%.1f g".format(recipe.chPerServing), highlight = true)
                recipe.proteinPerServing?.let { MacroCell("Fehérje",  "%.1f g".format(it)) }
                recipe.fatPerServing?.let    { MacroCell("Zsír",     "%.1f g".format(it)) }
                recipe.fiberPerServing?.let  { MacroCell("Rost",     "%.1f g".format(it)) }
                MacroCell("Idő", "${recipe.prepMinutes + recipe.cookMinutes} perc")
            }
        }

        // --- Eligible slots ---
        if (recipe.eligibleSlots.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                recipe.eligibleSlots.sorted().forEach { slot ->
                    AssistChip(onClick = {}, label = { Text(slot.displayName()) })
                }
            }
        }

        // --- Advance prep hint ---
        recipe.advancePrepHint?.let { hint ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Schedule, null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(18.dp).align(Alignment.Top))
                    Text(hint, style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }

        // --- Ingredients ---
        if (recipe.ingredients.isNotEmpty()) {
            SectionHeader("Hozzávalók (${recipe.baseServings} adaghoz)")
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recipe.ingredients.forEach { line ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                buildString {
                                    append(line.ingredientName)
                                    if (!line.prepNote.isNullOrBlank()) append(" (${line.prepNote})")
                                },
                                style    = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                            Text(
                                "%.0f g".format(line.gramsForBaseServings),
                                style     = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color     = MaterialTheme.colorScheme.primary,
                            )
                        }
                        if (line != recipe.ingredients.last())
                            HorizontalDivider(thickness = 0.5.dp)
                    }
                }
            }
        }

        // --- Instructions ---
        if (recipe.instructionsMd.isNotBlank()) {
            SectionHeader("Elkészítés")
            Card(modifier = Modifier.fillMaxWidth()) {
                // Minimal markdown rendering: split by line, render ##, -, numbered items
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    recipe.instructionsMd
                        .lines()
                        .filter { it.isNotBlank() }
                        .forEach { line ->
                            when {
                                line.startsWith("## ") -> Text(
                                    line.removePrefix("## "),
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                line.startsWith("# ")  -> Text(
                                    line.removePrefix("# "),
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                line.startsWith("- ")  -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("•", style = MaterialTheme.typography.bodyMedium)
                                    Text(line.removePrefix("- "), style = MaterialTheme.typography.bodyMedium)
                                }
                                line.first().isDigit() && line.contains(". ") -> Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.Top,
                                ) {
                                    val dot = line.indexOf(". ")
                                    Text(line.substring(0, dot + 1), style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.primary)
                                    Text(line.substring(dot + 2), style = MaterialTheme.typography.bodyMedium)
                                }
                                else -> Text(line, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                }
            }
        }

        Spacer(Modifier.height(80.dp)) // FAB safe zone
    }
}

@Composable
private fun MacroCell(label: String, value: String, highlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            style     = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color     = if (highlight) MaterialTheme.colorScheme.onPrimaryContainer
                        else MaterialTheme.colorScheme.onSurface,
        )
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

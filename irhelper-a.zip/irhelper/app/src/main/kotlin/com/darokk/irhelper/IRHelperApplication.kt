package com.darokk.irhelper

import android.app.Application
import com.darokk.irhelper.data.seed.SeedLoader
import com.darokk.irhelper.di.appModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class IRHelperApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val seedLoader: SeedLoader by inject()

    override fun onCreate() {
        super.onCreate()

        startKoin {
            androidContext(this@IRHelperApplication)
            modules(appModule)
        }

        // Seed DB on first launch (no-op if already seeded)
        appScope.launch {
            seedLoader.seedIfNeeded()
        }
    }
}

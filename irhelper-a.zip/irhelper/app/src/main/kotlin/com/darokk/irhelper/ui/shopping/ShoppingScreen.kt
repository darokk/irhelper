package com.darokk.irhelper.ui.shopping

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.PlanRepository
import com.darokk.irhelper.data.repository.ShoppingListRepository
import com.darokk.irhelper.domain.model.*
import com.darokk.irhelper.domain.usecase.GenerateShoppingListUseCase
import com.darokk.irhelper.ui.components.EmptyState
import com.darokk.irhelper.ui.components.SectionHeader
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import org.koin.androidx.compose.koinViewModel
import java.util.UUID

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

data class ShoppingUiState(
    val itemsByAisle: Map<StoreAisle, List<ShoppingListItem>> = emptyMap(),
    val totalCount: Int = 0,
    val checkedCount: Int = 0,
    val isLoading: Boolean = true,
    val isGenerating: Boolean = false,
    val activePlanId: String? = null,
)

class ShoppingViewModel(
    private val shoppingRepo: ShoppingListRepository,
    private val planRepo: PlanRepository,
    private val generateUseCase: GenerateShoppingListUseCase,
) : ViewModel() {

    private val _isGenerating = MutableStateFlow(false)

    val uiState: StateFlow<ShoppingUiState> = combine(
        shoppingRepo.allItems,
        planRepo.activePlan,
        _isGenerating,
    ) { items, plan, generating ->
        val grouped = items
            .sortedWith(compareBy({ it.aisle }, { it.customLabel ?: "" }))
            .groupBy { it.aisle }
        ShoppingUiState(
            itemsByAisle  = grouped,
            totalCount    = items.size,
            checkedCount  = items.count { it.isChecked },
            isLoading     = false,
            isGenerating  = generating,
            activePlanId  = plan?.id,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ShoppingUiState())

    fun toggleChecked(item: ShoppingListItem) {
        viewModelScope.launch {
            shoppingRepo.setChecked(item.id, !item.isChecked)
        }
    }

    fun deleteItem(item: ShoppingListItem) {
        viewModelScope.launch { shoppingRepo.deleteById(item.id) }
    }

    fun deleteChecked() {
        viewModelScope.launch { shoppingRepo.deleteChecked() }
    }

    fun generateFromPlan() {
        val planId = uiState.value.activePlanId ?: return
        viewModelScope.launch {
            _isGenerating.value = true
            try { generateUseCase(planId) }
            finally { _isGenerating.value = false }
        }
    }

    fun addManualItem(label: String, aisle: StoreAisle = StoreAisle.OTHER) {
        viewModelScope.launch {
            shoppingRepo.insert(
                ShoppingListItem(
                    id              = UUID.randomUUID().toString(),
                    planId          = null,
                    ingredientId    = null,
                    customLabel     = label,
                    quantityGrams   = null,
                    quantityDisplay = null,
                    aisle           = aisle,
                    kind            = ItemKind.NON_FOOD,
                    isChecked       = false,
                    createdAt       = Clock.System.now(),
                )
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(vm: ShoppingViewModel = koinViewModel()) {
    val state by vm.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Bevásárlólista")
                        if (!state.isLoading) {
                            Text(
                                "${state.checkedCount}/${state.totalCount} kész",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    if (state.checkedCount > 0) {
                        IconButton(onClick = vm::deleteChecked) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "Kész törlése")
                        }
                    }
                    IconButton(
                        onClick  = vm::generateFromPlan,
                        enabled  = !state.isGenerating && state.activePlanId != null,
                    ) {
                        if (state.isGenerating)
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        else
                            Icon(Icons.Filled.Refresh, contentDescription = "Lista generálása")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Hozzáad")
            }
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (state.itemsByAisle.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding)) {
                EmptyState("A bevásárlólista üres.\nGeneráld a tervből a ↺ gombbal, vagy adj hozzá manuálisan.")
            }
            return@Scaffold
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(padding),
        ) {
            state.itemsByAisle.entries
                .sortedBy { it.key }
                .forEach { (aisle, items) ->
                    item(key = "header-$aisle") {
                        SectionHeader(
                            aisleName(aisle),
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
                        )
                    }
                    items(items, key = { it.id }) { item ->
                        ShoppingItemRow(
                            item    = item,
                            onToggle = { vm.toggleChecked(item) },
                            onDelete = { vm.deleteItem(item) },
                        )
                    }
                }
        }
    }

    if (showAddDialog) {
        AddManualItemDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { label ->
                vm.addManualItem(label)
                showAddDialog = false
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShoppingItemRow(
    item: ShoppingListItem,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value == SwipeToDismissBoxValue.EndToStart) { onDelete(); true } else false
        }
    )

    SwipeToDismissBox(
        state            = dismissState,
        backgroundContent = {
            Box(
                Modifier.fillMaxSize()
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Icon(Icons.Filled.Delete, contentDescription = "Törlés",
                    tint = MaterialTheme.colorScheme.error)
            }
        },
        enableDismissFromStartToEnd = false,
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            onClick  = onToggle,
        ) {
            Row(
                modifier            = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment   = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Checkbox(checked = item.isChecked, onCheckedChange = { onToggle() })
                Column(Modifier.weight(1f)) {
                    Text(
                        text           = item.customLabel ?: item.quantityDisplay ?: "–",
                        style          = MaterialTheme.typography.bodyMedium,
                        textDecoration = if (item.isChecked) TextDecoration.LineThrough else null,
                        color          = if (item.isChecked) MaterialTheme.colorScheme.onSurfaceVariant
                                         else MaterialTheme.colorScheme.onSurface,
                    )
                    if (item.quantityDisplay != null && item.customLabel != null) {
                        Text(
                            item.quantityDisplay,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (item.kind == ItemKind.MANUAL_FOOD || item.kind == ItemKind.NON_FOOD) {
                    Icon(
                        Icons.Filled.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.secondary,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddManualItemDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title   = { Text("Tétel hozzáadása") },
        text    = {
            OutlinedTextField(
                value         = text,
                onValueChange = { text = it },
                placeholder   = { Text("pl. Rozskenyér, mosószer…") },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) { Text("Hozzáad") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Mégsem") }
        }
    )
}

private fun aisleName(aisle: StoreAisle): String = when (aisle) {
    StoreAisle.PRODUCE    -> "Zöldség, gyümölcs"
    StoreAisle.DAIRY      -> "Tejtermékek"
    StoreAisle.MEAT       -> "Hús"
    StoreAisle.FISH       -> "Hal"
    StoreAisle.BAKERY     -> "Pékáru"
    StoreAisle.DRY_GOODS  -> "Száraz alapanyagok"
    StoreAisle.CANNED     -> "Konzerv"
    StoreAisle.FROZEN     -> "Mélyhűtött"
    StoreAisle.CONDIMENTS -> "Fűszerek, szószok"
    StoreAisle.BEVERAGES  -> "Italok"
    StoreAisle.HOUSEHOLD  -> "Háztartási"
    StoreAisle.OTHER      -> "Egyéb"
}

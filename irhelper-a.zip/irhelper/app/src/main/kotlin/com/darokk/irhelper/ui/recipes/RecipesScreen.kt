package com.darokk.irhelper.ui.recipes

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.RecipeRepository
import com.darokk.irhelper.domain.model.*
import com.darokk.irhelper.ui.components.EmptyState
import com.darokk.irhelper.ui.components.RecipeSummaryCard
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

data class RecipesUiState(
    val recipes: List<Recipe> = emptyList(),
    val query: String = "",
    val filterSlot: Slot? = null,
    val filterSpeed: CarbSpeed? = null,
    val isLoading: Boolean = true,
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class RecipesViewModel(private val repo: RecipeRepository) : ViewModel() {

    private val _query       = MutableStateFlow("")
    private val _filterSlot  = MutableStateFlow<Slot?>(null)
    private val _filterSpeed = MutableStateFlow<CarbSpeed?>(null)

    val uiState: StateFlow<RecipesUiState> = combine(
        _query.debounce(200).flatMapLatest { q ->
            if (q.isBlank()) repo.all else repo.search(q)
        },
        _query,
        _filterSlot,
        _filterSpeed,
    ) { allRecipes, query, slot, speed ->
        val filtered = allRecipes
            .filter { r -> slot  == null || slot  in r.eligibleSlots }
            .filter { r -> speed == null || speed == r.speedClassification }
        RecipesUiState(
            recipes      = filtered,
            query        = query,
            filterSlot   = slot,
            filterSpeed  = speed,
            isLoading    = false,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RecipesUiState())

    fun onQueryChange(q: String)            { _query.value       = q }
    fun onSlotFilter(s: Slot?)              { _filterSlot.value  = s }
    fun onSpeedFilter(s: CarbSpeed?)        { _filterSpeed.value = s }
}

// ---------------------------------------------------------------------------
// Full Recipes Screen
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipesScreen(
    onRecipeClick: (String) -> Unit,
    onNavigateUp: () -> Unit,
    vm: RecipesViewModel = koinViewModel(),
) {
    val state by vm.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Vissza")
                    }
                },
                title = { Text("Receptek") },
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            // Search bar
            SearchBar(
                query          = state.query,
                onQueryChange  = vm::onQueryChange,
                modifier       = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            )

            // Filter chips
            FilterRow(
                selectedSlot  = state.filterSlot,
                selectedSpeed = state.filterSpeed,
                onSlotFilter  = vm::onSlotFilter,
                onSpeedFilter = vm::onSpeedFilter,
                modifier      = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )

            // Count
            Text(
                "${state.recipes.size} recept",
                style    = MaterialTheme.typography.labelMedium,
                color    = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
            )

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (state.recipes.isEmpty()) {
                EmptyState("Nincs találat")
            } else {
                LazyColumn(
                    contentPadding    = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.recipes, key = { it.id }) { recipe ->
                        RecipeSummaryCard(
                            name          = recipe.nameHu,
                            chPerServing  = recipe.chPerServing,
                            speed         = recipe.speedClassification,
                            slots         = recipe.eligibleSlots,
                            prepMinutes   = recipe.prepMinutes,
                            cookMinutes   = recipe.cookMinutes,
                            onClick       = { onRecipeClick(recipe.id) },
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Recipe Picker Bottom Sheet (used by Planner)
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipePickerBottomSheet(
    slot: Slot,
    onDismiss: () -> Unit,
    onSelectRecipe: (Recipe) -> Unit,
    onViewRecipe: (String) -> Unit,
    onRemove: (() -> Unit)?,
    vm: RecipesViewModel = koinViewModel(),
) {
    // Pre-filter by the selected slot
    LaunchedEffect(slot) { vm.onSlotFilter(slot) }

    val state by vm.uiState.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = {
            vm.onSlotFilter(null)
            onDismiss()
        },
        sheetState = sheetState,
    ) {
        Column(modifier = Modifier.padding(bottom = 24.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Recept – ${slot.displayName()}",
                    style = MaterialTheme.typography.titleMedium,
                )
                if (onRemove != null) {
                    TextButton(onClick = onRemove, colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )) {
                        Text("Eltávolítás")
                    }
                }
            }
            Spacer(Modifier.height(4.dp))

            SearchBar(
                query         = state.query,
                onQueryChange = vm::onQueryChange,
                modifier      = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            )

            if (state.recipes.isEmpty()) {
                EmptyState("Nincs megfelelő recept")
            } else {
                LazyColumn(
                    contentPadding    = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier          = Modifier.heightIn(max = 500.dp),
                ) {
                    items(state.recipes, key = { it.id }) { recipe ->
                        RecipeSummaryCard(
                            name         = recipe.nameHu,
                            chPerServing = recipe.chPerServing,
                            speed        = recipe.speedClassification,
                            slots        = recipe.eligibleSlots,
                            prepMinutes  = recipe.prepMinutes,
                            cookMinutes  = recipe.cookMinutes,
                            onClick      = { onSelectRecipe(recipe) },
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Shared sub-composables
// ---------------------------------------------------------------------------

@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value         = query,
        onValueChange = onQueryChange,
        modifier      = modifier,
        placeholder   = { Text("Keresés…") },
        leadingIcon   = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon  = if (query.isNotEmpty()) ({
            IconButton(onClick = { onQueryChange("") }) {
                Icon(Icons.Filled.Clear, contentDescription = "Törlés")
            }
        }) else null,
        singleLine    = true,
    )
}

@Composable
private fun FilterRow(
    selectedSlot: Slot?,
    selectedSpeed: CarbSpeed?,
    onSlotFilter: (Slot?) -> Unit,
    onSpeedFilter: (CarbSpeed?) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyRow(
        modifier            = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Slot filters
        items(Slot.entries) { slot ->
            FilterChip(
                selected  = selectedSlot == slot,
                onClick   = { onSlotFilter(if (selectedSlot == slot) null else slot) },
                label     = { Text(slot.displayName()) },
            )
        }
        // Speed filters
        items(CarbSpeed.entries) { speed ->
            FilterChip(
                selected  = selectedSpeed == speed,
                onClick   = { onSpeedFilter(if (selectedSpeed == speed) null else speed) },
                label     = {
                    Text(when (speed) {
                        CarbSpeed.SLOW        -> "Lassú"
                        CarbSpeed.MEDIUM      -> "Közép"
                        CarbSpeed.FAST        -> "Gyors"
                        CarbSpeed.NOT_COUNTED -> "–"
                    })
                },
            )
        }
    }
}

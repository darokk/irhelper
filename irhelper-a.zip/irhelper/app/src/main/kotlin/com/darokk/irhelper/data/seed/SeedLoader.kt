package com.darokk.irhelper.data.seed

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import com.darokk.irhelper.data.local.dao.IngredientDao
import com.darokk.irhelper.data.local.dao.RecipeDao
import com.darokk.irhelper.data.local.entity.IngredientEntity
import com.darokk.irhelper.data.local.entity.RecipeEntity
import com.darokk.irhelper.data.local.entity.RecipeIngredientEntity
import com.darokk.irhelper.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

private val KEY_SEED_DONE = booleanPreferencesKey("seed_loaded_v1")

private val lenientJson = Json {
    ignoreUnknownKeys = true
    isLenient = true
    // If a JSON value is `null` but the Kotlin field is non-nullable with a
    // default, fall back to the default instead of failing. Protects against
    // occasional nulls in the seed files (e.g. "instructionsMd": null).
    coerceInputValues = true
}

class SeedLoader(
    private val context: Context,
    private val ingredientDao: IngredientDao,
    private val recipeDao: RecipeDao,
    private val dataStore: DataStore<Preferences>,
) {
    /**
     * Call once on app startup (e.g. from Application.onCreate via coroutine).
     * No-ops if already seeded (guard stored in DataStore).
     */
    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        val prefs = dataStore.data.first()
        if (prefs[KEY_SEED_DONE] == true) return@withContext

        loadIngredients()
        loadRecipes()

        dataStore.edit { it[KEY_SEED_DONE] = true }
    }

    private suspend fun loadIngredients() {
        val raw = context.assets.open("seed/ingredients.json")
            .bufferedReader().readText()
        val file = lenientJson.decodeFromString<SeedIngredientFile>(raw)

        val entities = file.ingredients.mapNotNull { s ->
            runCatching {
                IngredientEntity(
                    id                 = s.id,
                    nameHu             = s.nameHu,
                    nameEn             = s.nameEn,
                    category           = enumValueOrDefault(s.category, IngredientCategory.OTHER),
                    aisle              = enumValueOrDefault(s.aisle, StoreAisle.OTHER),
                    chPer100g          = s.chPer100g,
                    speed              = enumValueOrDefault(s.speed, CarbSpeed.MEDIUM),
                    shelfLife          = enumValueOrDefault(s.shelfLife, ShelfLifeClass.SHORT),
                    shelfLifeDaysHint  = s.shelfLifeDaysHint,
                    servingHint        = s.servingHint,
                    isAssumedAvailable = s.isAssumedAvailable,
                    source             = s.source,
                    verified           = s.verified,
                )
            }.getOrNull()
        }

        ingredientDao.insertAll(entities)
    }

    private suspend fun loadRecipes() {
        val raw = context.assets.open("seed/recipes.json")
            .bufferedReader().readText()
        val file = lenientJson.decodeFromString<SeedRecipeFile>(raw)

        val recipeEntities = mutableListOf<RecipeEntity>()
        val ingredientLines = mutableListOf<RecipeIngredientEntity>()

        for (s in file.recipes) {
            runCatching {
                recipeEntities += RecipeEntity(
                    id                  = s.id,
                    nameHu              = s.nameHu,
                    descriptionHu       = s.descriptionHu,
                    eligibleSlots       = s.eligibleSlots
                        .mapNotNull { runCatching { Slot.valueOf(it) }.getOrNull() }
                        .toSet(),
                    speedClassification = enumValueOrDefault(s.speedClassification, CarbSpeed.MEDIUM),
                    baseServings        = s.baseServings,
                    chPerServing        = s.chPerServing,
                    proteinPerServing   = s.proteinPerServing,
                    fatPerServing       = s.fatPerServing,
                    fiberPerServing     = s.fiberPerServing,
                    prepMinutes         = s.prepMinutes,
                    cookMinutes         = s.cookMinutes,
                    instructionsMd      = s.instructionsMd,
                    goodAsLeftovers     = s.goodAsLeftovers,
                    advancePrepHint     = s.advancePrepHint,
                    isIRCompliant       = s.isIRCompliant,
                    source              = s.source,
                    verified            = s.verified,
                )
                for (ing in s.ingredients) {
                    ingredientLines += RecipeIngredientEntity(
                        recipeId             = s.id,
                        ingredientId         = ing.ingredientId,
                        ingredientName       = ing.ingredientName,
                        gramsForBaseServings = ing.gramsForBaseServings,
                        prepNote             = ing.prepNote,
                    )
                }
            }
        }

        recipeDao.insertAll(recipeEntities)
        recipeDao.insertAllIngredients(ingredientLines)
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(name: String, default: T): T =
        runCatching { enumValueOf<T>(name) }.getOrDefault(default)
}

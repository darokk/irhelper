package com.darokk.irhelper.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.darokk.irhelper.domain.model.CarbSpeed
import com.darokk.irhelper.domain.model.IngredientCategory
import com.darokk.irhelper.domain.model.ItemKind
import com.darokk.irhelper.domain.model.Slot
import com.darokk.irhelper.domain.model.SlotSchedule
import com.darokk.irhelper.domain.model.ShelfLifeClass
import com.darokk.irhelper.domain.model.StoreAisle
import kotlinx.datetime.Instant
import kotlinx.datetime.LocalDate

// ---------------------------------------------------------------------------
// UserEntity
// ---------------------------------------------------------------------------

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val hasIR: Boolean,
    val calorieTarget: Int,
    val chFractionOverride: Double?,
    val chTargetOverride: Int?,
    /** JSON-encoded SlotSchedule via TypeConverter */
    val slotSchedule: SlotSchedule,
    /** JSON-encoded Map<Slot, Int> via TypeConverter */
    val slotTargetsGrams: Map<Slot, Int>,
    val createdAt: Instant,
    val updatedAt: Instant,
)

// ---------------------------------------------------------------------------
// IngredientEntity
// ---------------------------------------------------------------------------

@Entity(tableName = "ingredients")
data class IngredientEntity(
    @PrimaryKey val id: String,
    val nameHu: String,
    val nameEn: String?,
    val category: IngredientCategory,
    val aisle: StoreAisle,
    val chPer100g: Double,
    val speed: CarbSpeed,
    val shelfLife: ShelfLifeClass,
    val shelfLifeDaysHint: Int,
    val servingHint: String?,
    val isAssumedAvailable: Boolean,
    val source: String,
    val verified: Boolean,
)

// ---------------------------------------------------------------------------
// RecipeEntity
// ---------------------------------------------------------------------------

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey val id: String,
    val nameHu: String,
    val descriptionHu: String?,
    /** Comma-separated Slot names via TypeConverter */
    val eligibleSlots: Set<Slot>,
    val speedClassification: CarbSpeed,
    val baseServings: Int,
    val chPerServing: Double,
    val proteinPerServing: Double?,
    val fatPerServing: Double?,
    val fiberPerServing: Double?,
    val prepMinutes: Int,
    val cookMinutes: Int,
    val instructionsMd: String,
    val goodAsLeftovers: Boolean,
    val advancePrepHint: String?,
    val isIRCompliant: Boolean,
    val source: String,
    val verified: Boolean,
)

// ---------------------------------------------------------------------------
// RecipeIngredientEntity  (join table)
// ---------------------------------------------------------------------------

@Entity(
    tableName = "recipe_ingredients",
    primaryKeys = ["recipeId", "ingredientId"],
    foreignKeys = [
        ForeignKey(
            entity        = RecipeEntity::class,
            parentColumns = ["id"],
            childColumns  = ["recipeId"],
            onDelete      = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("recipeId"), Index("ingredientId")],
)
data class RecipeIngredientEntity(
    val recipeId: String,
    val ingredientId: String,
    val ingredientName: String,   // denormalised for display
    val gramsForBaseServings: Double,
    val prepNote: String?,
)

// ---------------------------------------------------------------------------
// WeeklyPlanEntity
// ---------------------------------------------------------------------------

@Entity(tableName = "weekly_plans")
data class WeeklyPlanEntity(
    @PrimaryKey val id: String,      // "W2025-01-06"
    val startDate: LocalDate,
    val isActive: Boolean,
    val createdAt: Instant,
)

// ---------------------------------------------------------------------------
// PlannedMealEntity
// ---------------------------------------------------------------------------

@Entity(
    tableName = "planned_meals",
    foreignKeys = [
        ForeignKey(
            entity        = WeeklyPlanEntity::class,
            parentColumns = ["id"],
            childColumns  = ["planId"],
            onDelete      = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("planId"), Index("date"), Index("slot")],
)
data class PlannedMealEntity(
    @PrimaryKey val id: String,
    val planId: String,
    val date: LocalDate,
    val slot: Slot,
    val recipeId: String,
    val recipeName: String,
    val chPerServing: Double,
    val servingsCooked: Double,
    /** JSON-encoded List<String> via TypeConverter */
    val pairedMealIds: List<String>,
    val isCooked: Boolean,
    val notes: String?,
)

// ---------------------------------------------------------------------------
// ShoppingListItemEntity
// ---------------------------------------------------------------------------

@Entity(tableName = "shopping_list_items")
data class ShoppingListItemEntity(
    @PrimaryKey val id: String,
    val planId: String?,
    val ingredientId: String?,
    val customLabel: String?,
    val quantityGrams: Double?,
    val quantityDisplay: String?,
    val aisle: StoreAisle,
    val kind: ItemKind,
    val isChecked: Boolean,
    val createdAt: Instant,
)

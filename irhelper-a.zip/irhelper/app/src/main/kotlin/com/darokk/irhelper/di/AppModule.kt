package com.darokk.irhelper.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.darokk.irhelper.data.local.IRHelperDatabase
import com.darokk.irhelper.data.repository.*
import com.darokk.irhelper.data.seed.SeedLoader
import com.darokk.irhelper.domain.usecase.*
import com.darokk.irhelper.ui.cooking.CookingViewModel
import com.darokk.irhelper.ui.planner.PlannerViewModel
import com.darokk.irhelper.ui.recipes.RecipesViewModel
import com.darokk.irhelper.ui.settings.SettingsViewModel
import com.darokk.irhelper.ui.shopping.ShoppingViewModel
import com.darokk.irhelper.ui.today.TodayViewModel
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "irhelper_prefs")

val appModule = module {

    // --- DataStore ---
    single<DataStore<Preferences>> { androidContext().dataStore }

    // --- Room ---
    single {
        Room.databaseBuilder(
            androidContext(),
            IRHelperDatabase::class.java,
            IRHelperDatabase.DB_NAME,
        ).build()
    }

    // --- DAOs ---
    single { get<IRHelperDatabase>().userDao() }
    single { get<IRHelperDatabase>().ingredientDao() }
    single { get<IRHelperDatabase>().recipeDao() }
    single { get<IRHelperDatabase>().weeklyPlanDao() }
    single { get<IRHelperDatabase>().plannedMealDao() }
    single { get<IRHelperDatabase>().shoppingListDao() }

    // --- Repositories ---
    single { UserRepository(get()) }
    single { IngredientRepository(get()) }
    single { RecipeRepository(get()) }
    single { PlanRepository(get(), get()) }
    single { ShoppingListRepository(get()) }

    // --- Seed Loader ---
    single {
        SeedLoader(
            context       = androidContext(),
            ingredientDao = get(),
            recipeDao     = get(),
            dataStore     = get(),
        )
    }

    // --- Use Cases ---
    factory { ComputeCHTargetUseCase(get()) }
    factory { GetTodayMealsUseCase(get()) }
    factory { GetNextMealUseCase(get()) }
    factory { AssignRecipeToSlotUseCase(get(), get()) }
    factory { RemoveRecipeFromSlotUseCase(get()) }
    factory { EnsureActiveWeekPlanUseCase(get()) }
    factory { GenerateShoppingListUseCase(get(), get(), get(), get()) }

    // --- ViewModels ---
    viewModel { TodayViewModel(get(), get(), get()) }
    viewModel { PlannerViewModel(get(), get(), get(), get(), get()) }
    viewModel { ShoppingViewModel(get(), get(), get()) }
    viewModel { RecipesViewModel(get()) }
    viewModel { SettingsViewModel(get(), get()) }
    viewModel { (recipeId: String) -> CookingViewModel(recipeId, get()) }
}

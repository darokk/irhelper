# Keep Room entities and DAOs
-keep class com.darokk.irhelper.data.local.** { *; }
-keepclassmembers class * {
    @androidx.room.* <methods>;
    @androidx.room.* <fields>;
}

# Keep kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class **$$serializer { *; }
-keep @kotlinx.serialization.Serializable class * { *; }

# Keep Koin
-keep class org.koin.** { *; }

# Keep domain models (used by Room via reflection)
-keep class com.darokk.irhelper.domain.model.** { *; }
-keep class com.darokk.irhelper.data.seed.** { *; }

package com.darokk.irhelper.domain.model

import kotlinx.datetime.DayOfWeek
import kotlinx.datetime.Instant
import kotlinx.datetime.LocalDate

// ---------------------------------------------------------------------------
// SlotSchedule
// ---------------------------------------------------------------------------

/**
 * 7 × 6 grid: day-of-week → slot → status.
 * Stored as JSON string in Room via TypeConverter.
 */
data class SlotSchedule(
    val grid: Map<DayOfWeek, Map<Slot, SlotStatus>> = buildDefault()
) {
    fun statusFor(day: DayOfWeek, slot: Slot): SlotStatus =
        grid[day]?.get(slot) ?: SlotStatus.PLANNED

    companion object {
        fun buildDefault(): Map<DayOfWeek, Map<Slot, SlotStatus>> =
            DayOfWeek.entries.associateWith { _ ->
                Slot.entries.associateWith { SlotStatus.PLANNED }
            }
    }
}

// ---------------------------------------------------------------------------
// User
// ---------------------------------------------------------------------------

data class User(
    val id: String,
    val name: String,
    val hasIR: Boolean,
    val calorieTarget: Int,
    val chFractionOverride: Double?,
    val chTargetOverride: Int?,
    val slotSchedule: SlotSchedule,
    val slotTargetsGrams: Map<Slot, Int>,
    val createdAt: Instant,
    val updatedAt: Instant,
)

// ---------------------------------------------------------------------------
// Ingredient
// ---------------------------------------------------------------------------

data class Ingredient(
    val id: String,
    val nameHu: String,
    val nameEn: String?,
    val category: IngredientCategory,
    val aisle: StoreAisle,
    val chPer100g: Double,
    val speed: CarbSpeed,
    val shelfLife: ShelfLifeClass,
    val shelfLifeDaysHint: Int,
    val servingHint: String?,
    val isAssumedAvailable: Boolean,
    val source: String,
    val verified: Boolean,
)

// ---------------------------------------------------------------------------
// Recipe
// ---------------------------------------------------------------------------

data class RecipeIngredientLine(
    val ingredientId: String,
    val ingredientName: String,   // denormalised for display speed
    val gramsForBaseServings: Double,
    val prepNote: String?,
)

data class Recipe(
    val id: String,
    val nameHu: String,
    val descriptionHu: String?,
    val eligibleSlots: Set<Slot>,
    val speedClassification: CarbSpeed,
    val baseServings: Int,
    val chPerServing: Double,
    val proteinPerServing: Double?,
    val fatPerServing: Double?,
    val fiberPerServing: Double?,
    val prepMinutes: Int,
    val cookMinutes: Int,
    val instructionsMd: String,
    val goodAsLeftovers: Boolean,
    val advancePrepHint: String?,
    val isIRCompliant: Boolean,
    val source: String,
    val verified: Boolean,
    val ingredients: List<RecipeIngredientLine>,
) {
    val totalMinutes: Int get() = prepMinutes + cookMinutes
}

// ---------------------------------------------------------------------------
// WeeklyPlan + PlannedMeal
// ---------------------------------------------------------------------------

data class WeeklyPlan(
    val id: String,          // "W2025-01-06"
    val startDate: LocalDate,
    val isActive: Boolean,
    val createdAt: Instant,
)

data class PlannedMeal(
    val id: String,
    val planId: String,
    val date: LocalDate,
    val slot: Slot,
    val recipeId: String,
    val recipeName: String,   // denormalised for quick display
    val chPerServing: Double,
    val servingsCooked: Double,
    val pairedMealIds: List<String>,
    val isCooked: Boolean,
    val notes: String?,
)

// ---------------------------------------------------------------------------
// ShoppingListItem (persisted row)
// ---------------------------------------------------------------------------

data class ShoppingListItem(
    val id: String,
    val planId: String?,
    val ingredientId: String?,
    val customLabel: String?,
    val quantityGrams: Double?,
    val quantityDisplay: String?,
    val aisle: StoreAisle,
    val kind: ItemKind,
    val isChecked: Boolean,
    val createdAt: Instant,
)

// ---------------------------------------------------------------------------
// ShoppingRow (UI-facing)
// ---------------------------------------------------------------------------

/**
 * UI row for the shopping list. Bundles the persisted [ShoppingListItem]
 * with a resolved [displayName] so the view layer doesn't need to look
 * anything up itself.
 *
 *   • PLAN_FOOD                → name from joined Ingredient.nameHu
 *   • MANUAL_FOOD / NON_FOOD   → name from customLabel
 *   • anything else            → "(ismeretlen tétel)" fallback
 */
data class ShoppingRow(
    val item: ShoppingListItem,
    val displayName: String,
)

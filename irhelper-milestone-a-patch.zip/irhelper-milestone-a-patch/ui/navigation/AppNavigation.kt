package com.darokk.irhelper.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.darokk.irhelper.ui.cooking.CookingScreen
import com.darokk.irhelper.ui.planner.PlannerScreen
import com.darokk.irhelper.ui.recipes.RecipesScreen
import com.darokk.irhelper.ui.settings.SettingsScreen
import com.darokk.irhelper.ui.shopping.ShoppingScreen
import com.darokk.irhelper.ui.today.TodayScreen
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------
// Route constants
//
// The three primary tabs live inside a single HOME destination that hosts a
// HorizontalPager. Swiping between them, and tapping the bottom nav, both
// drive the same pagerState — so there's exactly one navigation path and it
// can't get into an inconsistent state.
//
// Secondary screens (Recipes, Cooking, Settings) remain separate NavHost
// routes reached via NavController.navigate.
// ---------------------------------------------------------------------------

object Routes {
    const val HOME     = "home"
    const val RECIPES  = "recipes"
    const val SETTINGS = "settings"
    const val COOKING  = "cooking/{recipeId}"

    fun cooking(recipeId: String) = "cooking/$recipeId"
}

// ---------------------------------------------------------------------------
// Home tabs
// ---------------------------------------------------------------------------

private const val PAGE_TODAY    = 0
private const val PAGE_PLANNER  = 1
private const val PAGE_SHOPPING = 2

private data class HomeTab(
    val label: String,
    val icon: ImageVector,
)

private val homeTabs = listOf(
    HomeTab("Ma",         Icons.Filled.Today),
    HomeTab("Tervező",    Icons.Filled.CalendarMonth),
    HomeTab("Bevásárlás", Icons.Filled.ShoppingCart),
)

// ---------------------------------------------------------------------------
// AppNavigation
// ---------------------------------------------------------------------------

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController    = navController,
        startDestination = Routes.HOME,
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onViewRecipe  = { navController.navigate(Routes.cooking(it)) },
                onOpenRecipes = { navController.navigate(Routes.RECIPES) },
            )
        }
        composable(Routes.RECIPES) {
            RecipesScreen(
                onRecipeClick = { navController.navigate(Routes.cooking(it)) },
                onNavigateUp  = { navController.navigateUp() },
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onNavigateUp = { navController.navigateUp() })
        }
        composable(
            route     = Routes.COOKING,
            arguments = listOf(navArgument("recipeId") { type = NavType.StringType }),
        ) { backStack ->
            val recipeId = backStack.arguments?.getString("recipeId") ?: return@composable
            CookingScreen(
                recipeId     = recipeId,
                onNavigateUp = { navController.navigateUp() },
            )
        }
    }
}

// ---------------------------------------------------------------------------
// HomeScreen — bottom NavigationBar + HorizontalPager over the 3 main tabs
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    onViewRecipe: (String) -> Unit,
    onOpenRecipes: () -> Unit,
) {
    // rememberPagerState persists through config changes and — because each
    // NavHost destination has its own SavedStateHandle — also across
    // round-trips to Recipes/Cooking/Settings and back.
    val pagerState = rememberPagerState(
        initialPage = PAGE_TODAY,
        pageCount   = { homeTabs.size },
    )
    val scope = rememberCoroutineScope()

    Scaffold(
        bottomBar = {
            NavigationBar {
                homeTabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = pagerState.currentPage == index,
                        onClick  = {
                            scope.launch { pagerState.animateScrollToPage(index) }
                        },
                        icon  = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                    )
                }
            }
        }
    ) { innerPadding ->
        // HorizontalPager participates in nested scrolling: a child that uses
        // Modifier.horizontalScroll() (like the Planner's 7-day grid) will
        // consume horizontal drags first, and only forward the leftover delta
        // to the pager when it hits its own scroll-edge. That gives the
        // requested behavior of "swipe changes tabs only when the inner grid
        // can't scroll any further in that direction".
        HorizontalPager(
            state    = pagerState,
            modifier = Modifier.padding(innerPadding),
        ) { page ->
            when (page) {
                PAGE_TODAY -> TodayScreen(
                    onViewRecipe   = onViewRecipe,
                    onOpenShopping = {
                        scope.launch { pagerState.animateScrollToPage(PAGE_SHOPPING) }
                    },
                )
                PAGE_PLANNER -> PlannerScreen(
                    onViewRecipe  = onViewRecipe,
                    onOpenRecipes = onOpenRecipes,
                )
                PAGE_SHOPPING -> ShoppingScreen()
            }
        }
    }
}

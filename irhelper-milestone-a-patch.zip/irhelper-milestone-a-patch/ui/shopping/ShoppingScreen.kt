package com.darokk.irhelper.ui.shopping

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.PlanRepository
import com.darokk.irhelper.data.repository.ShoppingListRepository
import com.darokk.irhelper.domain.model.ItemKind
import com.darokk.irhelper.domain.model.ShoppingListItem
import com.darokk.irhelper.domain.model.ShoppingRow
import com.darokk.irhelper.domain.model.StoreAisle
import com.darokk.irhelper.domain.usecase.GenerateShoppingListUseCase
import com.darokk.irhelper.ui.components.EmptyState
import com.darokk.irhelper.ui.components.SectionHeader
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import org.koin.androidx.compose.koinViewModel
import java.util.UUID

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

data class ShoppingUiState(
    val rowsByAisle: Map<StoreAisle, List<ShoppingRow>> = emptyMap(),
    val totalCount: Int = 0,
    val checkedCount: Int = 0,
    val isLoading: Boolean = true,
    val isGenerating: Boolean = false,
    val activePlanId: String? = null,
)

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

class ShoppingViewModel(
    private val shoppingRepo: ShoppingListRepository,
    private val planRepo: PlanRepository,
    private val generateUseCase: GenerateShoppingListUseCase,
) : ViewModel() {

    private val _isGenerating = MutableStateFlow(false)

    val uiState: StateFlow<ShoppingUiState> = combine(
        shoppingRepo.allRows,
        planRepo.activePlan,
        _isGenerating,
    ) { rows, plan, generating ->
        val grouped = rows
            .sortedWith(compareBy({ it.item.aisle }, { it.displayName.lowercase() }))
            .groupBy { it.item.aisle }
        ShoppingUiState(
            rowsByAisle  = grouped,
            totalCount   = rows.size,
            checkedCount = rows.count { it.item.isChecked },
            isLoading    = false,
            isGenerating = generating,
            activePlanId = plan?.id,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ShoppingUiState())

    fun toggleChecked(item: ShoppingListItem) {
        viewModelScope.launch {
            shoppingRepo.setChecked(item.id, !item.isChecked)
        }
    }

    fun deleteItem(item: ShoppingListItem) {
        viewModelScope.launch { shoppingRepo.deleteById(item.id) }
    }

    fun deleteChecked() {
        viewModelScope.launch { shoppingRepo.deleteChecked() }
    }

    fun generateFromPlan() {
        val planId = uiState.value.activePlanId ?: return
        viewModelScope.launch {
            _isGenerating.value = true
            try { generateUseCase(planId) }
            finally { _isGenerating.value = false }
        }
    }

    fun addManualItem(label: String, aisle: StoreAisle = StoreAisle.OTHER) {
        viewModelScope.launch {
            shoppingRepo.insert(
                ShoppingListItem(
                    id              = UUID.randomUUID().toString(),
                    planId          = null,
                    ingredientId    = null,
                    customLabel     = label,
                    quantityGrams   = null,
                    quantityDisplay = null,
                    aisle           = aisle,
                    kind            = ItemKind.NON_FOOD,
                    isChecked       = false,
                    createdAt       = Clock.System.now(),
                )
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(vm: ShoppingViewModel = koinViewModel()) {
    val state by vm.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Bevásárlólista")
                        if (!state.isLoading) {
                            Text(
                                "${state.checkedCount}/${state.totalCount} kész",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    if (state.checkedCount > 0) {
                        IconButton(onClick = vm::deleteChecked) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "Kész törlése")
                        }
                    }
                    IconButton(
                        onClick = vm::generateFromPlan,
                        enabled = !state.isGenerating && state.activePlanId != null,
                    ) {
                        if (state.isGenerating)
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                        else
                            Icon(Icons.Filled.Refresh, contentDescription = "Lista generálása")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Hozzáad")
            }
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (state.rowsByAisle.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding)) {
                EmptyState("A bevásárlólista üres.\nGeneráld a tervből a ↺ gombbal, vagy adj hozzá manuálisan.")
            }
            if (showAddDialog) {
                AddManualItemDialog(
                    onDismiss = { showAddDialog = false },
                    onConfirm = { label ->
                        vm.addManualItem(label)
                        showAddDialog = false
                    },
                )
            }
            return@Scaffold
        }

        LazyColumn(
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier            = Modifier.padding(padding),
        ) {
            state.rowsByAisle.entries
                .sortedBy { it.key }
                .forEach { (aisle, rows) ->
                    item(key = "header-$aisle") {
                        SectionHeader(
                            aisleName(aisle),
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
                        )
                    }
                    items(rows, key = { it.item.id }) { row ->
                        ShoppingItemRow(
                            row      = row,
                            onToggle = { vm.toggleChecked(row.item) },
                            onDelete = { vm.deleteItem(row.item) },
                        )
                    }
                }
        }
    }

    if (showAddDialog) {
        AddManualItemDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { label ->
                vm.addManualItem(label)
                showAddDialog = false
            },
        )
    }
}

// ---------------------------------------------------------------------------
// Row
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShoppingItemRow(
    row: ShoppingRow,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    val item = row.item

    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value == SwipeToDismissBoxValue.EndToStart) { onDelete(); true } else false
        }
    )

    SwipeToDismissBox(
        state             = dismissState,
        backgroundContent = {
            Box(
                Modifier.fillMaxSize().padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "Törlés",
                    tint = MaterialTheme.colorScheme.error,
                )
            }
        },
        enableDismissFromStartToEnd = false,
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            onClick  = onToggle,
        ) {
            Row(
                modifier              = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Checkbox(
                    checked         = item.isChecked,
                    onCheckedChange = { onToggle() },
                )

                // Name (primary)
                Text(
                    text           = row.displayName,
                    style          = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (item.isChecked) TextDecoration.LineThrough else TextDecoration.None,
                    color          = when {
                        item.isChecked                -> MaterialTheme.colorScheme.onSurfaceVariant
                        item.kind == ItemKind.MANUAL_FOOD -> MaterialTheme.colorScheme.tertiary
                        item.kind == ItemKind.NON_FOOD    -> MaterialTheme.colorScheme.secondary
                        else                          -> MaterialTheme.colorScheme.onSurface
                    },
                    modifier = Modifier.weight(1f),
                )

                // Quantity (trailing, secondary)
                val qty = item.quantityDisplay
                    ?: item.quantityGrams?.let { formatGrams(it) }
                if (qty != null) {
                    Text(
                        text  = qty,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                // Manual/non-food marker
                if (item.kind == ItemKind.MANUAL_FOOD || item.kind == ItemKind.NON_FOOD) {
                    Icon(
                        Icons.Filled.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint     = MaterialTheme.colorScheme.secondary,
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Add-item dialog
// ---------------------------------------------------------------------------

@Composable
private fun AddManualItemDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tétel hozzáadása") },
        text  = {
            OutlinedTextField(
                value         = text,
                onValueChange = { text = it },
                placeholder   = { Text("pl. Rozskenyér, mosószer…") },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onConfirm(text.trim()) }) {
                Text("Hozzáad")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Mégsem") }
        }
    )
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

private fun aisleName(aisle: StoreAisle): String = when (aisle) {
    StoreAisle.PRODUCE    -> "Zöldség, gyümölcs"
    StoreAisle.DAIRY      -> "Tejtermékek"
    StoreAisle.MEAT       -> "Hús"
    StoreAisle.FISH       -> "Hal"
    StoreAisle.BAKERY     -> "Pékáru"
    StoreAisle.DRY_GOODS  -> "Száraz alapanyagok"
    StoreAisle.CANNED     -> "Konzerv"
    StoreAisle.FROZEN     -> "Mélyhűtött"
    StoreAisle.CONDIMENTS -> "Fűszerek, szószok"
    StoreAisle.BEVERAGES  -> "Italok"
    StoreAisle.HOUSEHOLD  -> "Háztartási"
    StoreAisle.OTHER      -> "Egyéb"
}

private fun formatGrams(g: Double): String = when {
    g >= 1000 -> "%.1f kg".format(g / 1000)
    else      -> "%.0f g".format(g)
}

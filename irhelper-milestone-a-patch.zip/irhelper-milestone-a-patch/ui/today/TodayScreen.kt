package com.darokk.irhelper.ui.today

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darokk.irhelper.data.repository.PlanRepository
import com.darokk.irhelper.data.repository.ShoppingListRepository
import com.darokk.irhelper.data.repository.UserRepository
import com.darokk.irhelper.domain.model.PlannedMeal
import com.darokk.irhelper.domain.model.Slot
import com.darokk.irhelper.domain.model.User
import com.darokk.irhelper.domain.util.SlotDefaults
import com.darokk.irhelper.ui.components.EmptyState
import com.darokk.irhelper.ui.components.SectionHeader
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.todayIn
import org.koin.androidx.compose.koinViewModel

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

data class TodayUiState(
    val user: User? = null,
    val todayMeals: List<PlannedMeal> = emptyList(),
    val nextMeal: PlannedMeal? = null,
    val uncheckedShoppingCount: Int = 0,
    val remainingChBudget: Map<Slot, Int> = emptyMap(),
    val isLoading: Boolean = true,
)

// ---------------------------------------------------------------------------
// ViewModel
// ---------------------------------------------------------------------------

class TodayViewModel(
    private val userRepo: UserRepository,
    private val planRepo: PlanRepository,
    private val shoppingRepo: ShoppingListRepository,
) : ViewModel() {

    private val today = Clock.System.todayIn(TimeZone.currentSystemDefault())

    val uiState: StateFlow<TodayUiState> = combine(
        userRepo.activeUser,
        planRepo.mealsForDate(today),
        shoppingRepo.allItems,
    ) { user, meals, shopping ->
        val sortedMeals = meals.sortedBy { it.slot }
        val nextMeal    = sortedMeals.firstOrNull { !it.isCooked }
        val cookedSlots = sortedMeals.filter { it.isCooked }.map { it.slot }.toSet()

        val slotTargets = user?.slotTargetsGrams
            ?: SlotDefaults.grams.mapValues { it.value }

        val remaining = slotTargets
            .filterKeys { slot ->
                slot !in cookedSlots &&
                    sortedMeals.none { m -> m.slot == slot && m.isCooked }
            }

        TodayUiState(
            user                   = user,
            todayMeals             = sortedMeals,
            nextMeal               = nextMeal,
            uncheckedShoppingCount = shopping.count { !it.isChecked },
            remainingChBudget      = remaining,
            isLoading              = false,
        )
    }.stateIn(
        scope        = viewModelScope,
        started      = SharingStarted.WhileSubscribed(5_000),
        initialValue = TodayUiState(),
    )

    fun markCooked(meal: PlannedMeal) {
        viewModelScope.launch {
            planRepo.setMealCooked(meal.id, true)
        }
    }
}

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    onViewRecipe: (String) -> Unit,
    onOpenShopping: () -> Unit,
    vm: TodayViewModel = koinViewModel(),
) {
    val state by vm.uiState.collectAsState()
    val today = Clock.System.todayIn(TimeZone.currentSystemDefault())

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Ma", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text  = "${today.dayOfMonth}. ${monthName(today.monthNumber)} (${dayName(today.dayOfWeek.ordinal)})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                // No actions: navigation between tabs is bottom-nav + swipe only.
            )
        }
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // --- Next meal card ---
            val next = state.nextMeal
            if (next != null) {
                NextMealCard(
                    meal         = next,
                    onViewRecipe = { onViewRecipe(next.recipeId) },
                    onMarkCooked = { vm.markCooked(next) },
                )
            } else {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Nincs több tervezett étkezés ma 🎉",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            // --- Shopping list shortcut (still allowed — content-level nav,
            //     not a top-bar duplicate of the bottom nav) ---
            if (state.uncheckedShoppingCount > 0) {
                OutlinedCard(
                    onClick  = onOpenShopping,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier              = Modifier.padding(16.dp),
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(
                            Icons.Filled.ShoppingCart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            "${state.uncheckedShoppingCount} termék a bevásárlólistán",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Spacer(Modifier.weight(1f))
                        Icon(
                            Icons.Filled.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            // --- Remaining CH budget ---
            if (state.remainingChBudget.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier            = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        SectionHeader("Napi szénhidrát-keret maradéka")
                        val total = state.remainingChBudget.values.sum()
                        Text(
                            "Összesen: $total g SZ",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        state.remainingChBudget
                            .entries
                            .sortedBy { it.key }
                            .forEach { (slot, grams) ->
                                Row(
                                    modifier              = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    val time = SlotDefaults.times[slot]
                                    Text(
                                        "${slot.displayName()}${if (time != null) "  (${time.displayStart})" else ""}",
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                    Text(
                                        "$grams g",
                                        style      = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color      = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                    }
                }
            }

            // --- Today's schedule ---
            if (state.todayMeals.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier            = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        SectionHeader("Mai étkezések")
                        state.todayMeals.forEach { meal ->
                            Row(
                                modifier              = Modifier.fillMaxWidth(),
                                verticalAlignment     = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    if (meal.isCooked) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (meal.isCooked) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(20.dp),
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        meal.slot.displayName(),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    Text(
                                        meal.recipeName,
                                        style      = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (!meal.isCooked) FontWeight.Medium else FontWeight.Normal,
                                    )
                                }
                                Text(
                                    "%.0f g SZ".format(meal.chPerServing),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            } else {
                EmptyState("Nincs tervezett étkezés mára. Nyisd meg a Tervezőt!")
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Next-meal card
// ---------------------------------------------------------------------------

@Composable
private fun NextMealCard(
    meal: PlannedMeal,
    onViewRecipe: () -> Unit,
    onMarkCooked: () -> Unit,
) {
    val timeRange = SlotDefaults.times[meal.slot]
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
        ),
    ) {
        Column(
            modifier            = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "Következő étkezés",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    buildString {
                        append(meal.slot.displayName())
                        if (timeRange != null) append(" · ${timeRange.displayStart}")
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            Text(
                meal.recipeName,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
                "%.0f g SZ/adag".format(meal.chPerServing),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onViewRecipe) {
                    Icon(Icons.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Recept")
                }
                OutlinedButton(onClick = onMarkCooked) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Megfőzve")
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Hungarian day/month names
// ---------------------------------------------------------------------------

private fun monthName(month: Int): String = when (month) {
    1  -> "január";     2  -> "február";  3  -> "március"; 4  -> "április"
    5  -> "május";      6  -> "június";   7  -> "július";  8  -> "augusztus"
    9  -> "szeptember"; 10 -> "október";  11 -> "november"; 12 -> "december"
    else -> ""
}

private fun dayName(ordinal: Int): String = when (ordinal) {
    0 -> "hétfő"; 1 -> "kedd"; 2 -> "szerda"; 3 -> "csütörtök"
    4 -> "péntek"; 5 -> "szombat"; 6 -> "vasárnap"; else -> ""
}

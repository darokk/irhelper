package com.darokk.irhelper.data.repository

import com.darokk.irhelper.data.local.dao.IngredientDao
import com.darokk.irhelper.data.local.dao.PlannedMealDao
import com.darokk.irhelper.data.local.dao.RecipeDao
import com.darokk.irhelper.data.local.dao.ShoppingListDao
import com.darokk.irhelper.data.local.dao.UserDao
import com.darokk.irhelper.data.local.dao.WeeklyPlanDao
import com.darokk.irhelper.data.local.entity.IngredientEntity
import com.darokk.irhelper.data.local.entity.PlannedMealEntity
import com.darokk.irhelper.data.local.entity.RecipeEntity
import com.darokk.irhelper.data.local.entity.RecipeIngredientEntity
import com.darokk.irhelper.data.local.entity.ShoppingListItemEntity
import com.darokk.irhelper.data.local.entity.UserEntity
import com.darokk.irhelper.data.local.entity.WeeklyPlanEntity
import com.darokk.irhelper.domain.model.Ingredient
import com.darokk.irhelper.domain.model.PlannedMeal
import com.darokk.irhelper.domain.model.Recipe
import com.darokk.irhelper.domain.model.RecipeIngredientLine
import com.darokk.irhelper.domain.model.ShoppingListItem
import com.darokk.irhelper.domain.model.ShoppingRow
import com.darokk.irhelper.domain.model.Slot
import com.darokk.irhelper.domain.model.User
import com.darokk.irhelper.domain.model.WeeklyPlan
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.datetime.LocalDate

// ============================================================================
// Mappers (entity ↔ domain)
// ============================================================================

fun UserEntity.toDomain() = User(
    id                 = id,
    name               = name,
    hasIR              = hasIR,
    calorieTarget      = calorieTarget,
    chFractionOverride = chFractionOverride,
    chTargetOverride   = chTargetOverride,
    slotSchedule       = slotSchedule,
    slotTargetsGrams   = slotTargetsGrams,
    createdAt          = createdAt,
    updatedAt          = updatedAt,
)

fun User.toEntity() = UserEntity(
    id                 = id,
    name               = name,
    hasIR              = hasIR,
    calorieTarget      = calorieTarget,
    chFractionOverride = chFractionOverride,
    chTargetOverride   = chTargetOverride,
    slotSchedule       = slotSchedule,
    slotTargetsGrams   = slotTargetsGrams,
    createdAt          = createdAt,
    updatedAt          = updatedAt,
)

fun IngredientEntity.toDomain() = Ingredient(
    id                 = id,
    nameHu             = nameHu,
    nameEn             = nameEn,
    category           = category,
    aisle              = aisle,
    chPer100g          = chPer100g,
    speed              = speed,
    shelfLife          = shelfLife,
    shelfLifeDaysHint  = shelfLifeDaysHint,
    servingHint        = servingHint,
    isAssumedAvailable = isAssumedAvailable,
    source             = source,
    verified           = verified,
)

fun RecipeEntity.toDomain(ingredients: List<RecipeIngredientEntity>) = Recipe(
    id                  = id,
    nameHu              = nameHu,
    descriptionHu       = descriptionHu,
    eligibleSlots       = eligibleSlots,
    speedClassification = speedClassification,
    baseServings        = baseServings,
    chPerServing        = chPerServing,
    proteinPerServing   = proteinPerServing,
    fatPerServing       = fatPerServing,
    fiberPerServing     = fiberPerServing,
    prepMinutes         = prepMinutes,
    cookMinutes         = cookMinutes,
    instructionsMd      = instructionsMd,
    goodAsLeftovers     = goodAsLeftovers,
    advancePrepHint     = advancePrepHint,
    isIRCompliant       = isIRCompliant,
    source              = source,
    verified            = verified,
    ingredients         = ingredients.map { it.toDomain() },
)

fun RecipeIngredientEntity.toDomain() = RecipeIngredientLine(
    ingredientId         = ingredientId,
    ingredientName       = ingredientName,
    gramsForBaseServings = gramsForBaseServings,
    prepNote             = prepNote,
)

fun WeeklyPlanEntity.toDomain() = WeeklyPlan(
    id        = id,
    startDate = startDate,
    isActive  = isActive,
    createdAt = createdAt,
)

fun PlannedMealEntity.toDomain() = PlannedMeal(
    id             = id,
    planId         = planId,
    date           = date,
    slot           = slot,
    recipeId       = recipeId,
    recipeName     = recipeName,
    chPerServing   = chPerServing,
    servingsCooked = servingsCooked,
    pairedMealIds  = pairedMealIds,
    isCooked       = isCooked,
    notes          = notes,
)

fun PlannedMeal.toEntity() = PlannedMealEntity(
    id             = id,
    planId         = planId,
    date           = date,
    slot           = slot,
    recipeId       = recipeId,
    recipeName     = recipeName,
    chPerServing   = chPerServing,
    servingsCooked = servingsCooked,
    pairedMealIds  = pairedMealIds,
    isCooked       = isCooked,
    notes          = notes,
)

fun ShoppingListItemEntity.toDomain() = ShoppingListItem(
    id              = id,
    planId          = planId,
    ingredientId    = ingredientId,
    customLabel     = customLabel,
    quantityGrams   = quantityGrams,
    quantityDisplay = quantityDisplay,
    aisle           = aisle,
    kind            = kind,
    isChecked       = isChecked,
    createdAt       = createdAt,
)

fun ShoppingListItem.toEntity() = ShoppingListItemEntity(
    id              = id,
    planId          = planId,
    ingredientId    = ingredientId,
    customLabel     = customLabel,
    quantityGrams   = quantityGrams,
    quantityDisplay = quantityDisplay,
    aisle           = aisle,
    kind            = kind,
    isChecked       = isChecked,
    createdAt       = createdAt,
)

// ============================================================================
// UserRepository
// ============================================================================

class UserRepository(private val dao: UserDao) {
    val activeUser: Flow<User?> = dao.observeActiveUser().map { it?.toDomain() }

    suspend fun getActiveUser(): User? = dao.getActiveUser()?.toDomain()

    suspend fun upsert(user: User) = dao.upsert(user.toEntity())
}

// ============================================================================
// IngredientRepository
// ============================================================================

class IngredientRepository(private val dao: IngredientDao) {
    val all: Flow<List<Ingredient>> = dao.observeAll().map { it.map { e -> e.toDomain() } }

    fun search(query: String): Flow<List<Ingredient>> =
        dao.search(query).map { it.map { e -> e.toDomain() } }

    suspend fun getById(id: String): Ingredient? = dao.getById(id)?.toDomain()
}

// ============================================================================
// RecipeRepository
// ============================================================================

class RecipeRepository(private val dao: RecipeDao) {
    val all: Flow<List<Recipe>> = dao.observeAll().map { list ->
        list.map { entity ->
            val ings = dao.getIngredientsForRecipe(entity.id)
            entity.toDomain(ings)
        }
    }

    fun search(query: String): Flow<List<Recipe>> =
        dao.search(query).map { list ->
            list.map { entity ->
                val ings = dao.getIngredientsForRecipe(entity.id)
                entity.toDomain(ings)
            }
        }

    suspend fun getById(id: String): Recipe? {
        val entity = dao.getById(id) ?: return null
        val ings = dao.getIngredientsForRecipe(id)
        return entity.toDomain(ings)
    }
}

// ============================================================================
// PlanRepository
// ============================================================================

class PlanRepository(
    private val planDao: WeeklyPlanDao,
    private val mealDao: PlannedMealDao,
) {
    val activePlan: Flow<WeeklyPlan?> = planDao.observeActivePlan().map { it?.toDomain() }

    fun mealsForPlan(planId: String): Flow<List<PlannedMeal>> =
        mealDao.observeByPlan(planId).map { it.map { e -> e.toDomain() } }

    fun mealsForDate(date: LocalDate): Flow<List<PlannedMeal>> =
        mealDao.observeByDate(date).map { it.map { e -> e.toDomain() } }

    suspend fun getOrCreateActivePlan(id: String, startDate: LocalDate): String {
        val existing = planDao.getById(id)
        if (existing != null) return existing.id
        val entity = WeeklyPlanEntity(
            id        = id,
            startDate = startDate,
            isActive  = true,
            createdAt = kotlinx.datetime.Clock.System.now(),
        )
        planDao.insert(entity)
        return id
    }

    suspend fun insertMeal(meal: PlannedMeal) = mealDao.insert(meal.toEntity())

    suspend fun deleteMealAt(planId: String, date: LocalDate, slot: Slot) =
        mealDao.deleteAt(planId, date, slot)

    suspend fun setMealCooked(mealId: String, cooked: Boolean) =
        mealDao.setCooked(mealId, cooked)
}

// ============================================================================
// ShoppingListRepository
// ============================================================================

class ShoppingListRepository(private val dao: ShoppingListDao) {

    /** Raw items — retained for tests and non-UI consumers. */
    val allItems: Flow<List<ShoppingListItem>> =
        dao.observeAll().map { it.map { e -> e.toDomain() } }

    /**
     * Preferred source for the UI. Resolves display name via DAO join so
     * plan-generated rows show the ingredient name instead of a bare gram
     * count. Manual/free-text rows fall back to customLabel.
     */
    val allRows: Flow<List<ShoppingRow>> =
        dao.observeAllWithNames().map { projections ->
            projections.map { p ->
                ShoppingRow(
                    item        = p.item.toDomain(),
                    displayName = p.item.customLabel
                        ?: p.ingredientNameHu
                        ?: "(ismeretlen tétel)",
                )
            }
        }

    fun itemsForPlan(planId: String): Flow<List<ShoppingListItem>> =
        dao.observeByPlan(planId).map { it.map { e -> e.toDomain() } }

    suspend fun replacePlanItems(planId: String, items: List<ShoppingListItem>) {
        dao.deletePlanFoodItems(planId)
        dao.insertAll(items.map { it.toEntity() })
    }

    suspend fun insert(item: ShoppingListItem) = dao.insert(item.toEntity())

    suspend fun setChecked(id: String, checked: Boolean) = dao.setChecked(id, checked)

    suspend fun deleteById(id: String) = dao.deleteById(id)

    suspend fun deleteChecked() = dao.deleteChecked()
}
